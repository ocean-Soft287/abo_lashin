package com.abolashine.theOne.abolashin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
