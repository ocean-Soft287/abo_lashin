import '../../constans/constants.dart';

class Endpoints {

  static const String baseUrl = "http://15.235.51.177/TheOneAPI";


  static const String getMainCategory = "$baseUrl/api/Category/GetMainCategory";
  static const String register = "$baseUrl/api/Customer/AddCustomer";
  static const String getSubCategory = "$baseUrl/api/Category/GetCategoryByParentId";
  static const String updateUser = "$baseUrl/user/update";
  static const String aboutUS = "$baseUrl/api/AboutUs";
  static const String privacyAndPlo = "$baseUrl/api/Privacy";
  static const String governorates = "$baseUrl/api/Governorates";
  static const String addNewAddress = "$baseUrl/api/Customer/AddCustomerAddress";
  static  String offerOne = "$baseUrl/api/Offers?CustomerPhone=$customerPhone";
 static  String offerTwo = "$baseUrl/api/Offer1?CustomerPhone=$customerPhone";

  static String couponsDiscountCode(var discountCode) => "$baseUrl/api/Coupons/GetByCode/$discountCode?CustomerPhone=$customerPhone";
}
