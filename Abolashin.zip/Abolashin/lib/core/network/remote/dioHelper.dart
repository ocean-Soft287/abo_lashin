
import 'dart:convert';

import 'package:dio/dio.dart';

import 'end_point.dart';



class DioHelper{

  static late Dio dio;
  static init()
  {
    dio=Dio(BaseOptions(baseUrl:Endpoints.baseUrl,
    receiveDataWhenStatusError: true,
      headers: {
        'Accept': 'application/json',
        'Accept-Language': 'ar',
        // 'Content-Type': 'multipart/form-data',

     }


    ));

  }

  static Future<Response>getData({required String url,Map<String,dynamic>? query})async
  {
    dio.options.headers["Authorization"] = "Basic ZTBjOWRlMWIyZGUyNmZlMjpnOEV0eXg4VFU1Nzl2RHhKemFOMWxvM3I0NitXSkx2cWIvSU1ZZElVUkhNPQ==";
   return await dio.get(url,queryParameters: query);
  }

  static Future<Response>postData({required String url, dynamic data, String?token })async
  {
    dio.options.headers["Authorization"] = "Basic ZTBjOWRlMWIyZGUyNmZlMjpnOEV0eXg4VFU1Nzl2RHhKemFOMWxvM3I0NitXSkx2cWIvSU1ZZElVUkhNPQ==";
    return   dio.post(url,data: data);
  }

  static Future<Response>putData({required String url,Map<String,dynamic> ?data,String?token })async
  {
    dio.options.headers["Authorization"] = "Basic ZTBjOWRlMWIyZGUyNmZlMjpnOEV0eXg4VFU1Nzl2RHhKemFOMWxvM3I0NitXSkx2cWIvSU1ZZElVUkhNPQ==";
    return   dio.put(url,data: data);
  }
  static Future<Response>deleteData({required String url})async
  {
    dio.options.headers["Authorization"] = "Basic ZTBjOWRlMWIyZGUyNmZlMjpnOEV0eXg4VFU1Nzl2RHhKemFOMWxvM3I0NitXSkx2cWIvSU1ZZElVUkhNPQ==";
    return dio.delete(url);
  }
}