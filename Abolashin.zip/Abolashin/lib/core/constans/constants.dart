String? currentLang='ar';

dynamic userGoogle;
dynamic CustomerID;
dynamic customerPhone;