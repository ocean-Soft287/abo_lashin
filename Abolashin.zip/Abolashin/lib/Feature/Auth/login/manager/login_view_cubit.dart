
import 'dart:convert';


import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import '../../../../core/network/remote/dioHelper.dart';
import '../../../../core/network/remote/encrupt.dart';
import '../../../../core/sharde/widget/navigation.dart';
import '../../../../main.dart';
import '../../../main/Home/home_screen.dart';
import '../model/customer_model.dart';
import 'login_view_state.dart';





class LoginViewCubit extends Cubit<LoginViewState> {
  LoginViewCubit() : super(InitializeLoginViewState());

  void userLogin({required String customerPhone,required String password}) {
    emit(LoginViewStateLoading());
    DioHelper.getData(
     url: '/api/Customer/Login?CustomerPhone=$customerPhone&passWord=$password&Token=1111').then((value) {
      //url: '/api/Customer/Login?CustomerPhone=94440596&passWord=123456&Token=$token').then((value) {

      print('Success');
      print('الداتا قبل فك التشفير');
      print(value.data);

      print('الداتا بعد فك التشفير');
      final decryptedText = decrypt(value.data, privateKey, publicKey);



      print(decryptedText);

      dynamic jsonString = jsonEncode(decryptedText);
      print(jsonString);
      print(jsonString.runtimeType);
         if(value.data=="cXmUR9z1mAe20wCqm1ZR3Q==")
           {
             print('ggggggggggg');
             emit(LoginViewStateError(value.data));
           }
         else
           {
             print(decryptedText);
             Map<String, dynamic> customerMap = jsonDecode(decryptedText);

             // إنشاء كائن Customer من JSON
             Customer customer = Customer.fromJson(customerMap);
             print(customer.email);
             emit(LoginViewStateSuccess(customer));

           }


    }).catchError((error) {
      emit(LoginViewStateError(error.toString()));
      print('is Error == $error');
      print('Error in Login ');
    }
    );
  }











// Future<void> signInWithGoogle() async {
//     try {
//       emit( AuthGoogleLoading());
//       final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
//       final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;
//
//       final credential = GoogleAuthProvider.credential(
//         accessToken: googleAuth?.accessToken,
//         idToken: googleAuth?.idToken,
//       );
//
//       final UserCredential userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
//     print(userCredential.additionalUserInfo!.profile);
//
//       try {
//         await googleAuthData.add(userCredential.additionalUserInfo!.profile);
//         int count = googleAuthData.length;
//         print('تم إضافة العنصر بنجاح. عدد العناصر في الصندوق: $count');
//
//       } catch (e) {
//         print('حدث خطأ أثناء إضافة العنصر: $e');
//       }
//
//
//
//       emit( AuthGoogleSuccess(userCredential.additionalUserInfo!.profile));
//     } catch (e) {
//       print(e.toString());
//       emit( AuthGoogleFailure(e.toString()));
//     }
//   }
//
//   Future<void> signInWithFacebook() async {
//     try {
//       emit(AuthFacebookLoading());
//
//
//       final LoginResult loginResult = await FacebookAuth.instance.login();
//
//       if (loginResult.status == LoginStatus.success) {
//         // الحصول على credential
//         final OAuthCredential facebookAuthCredential = FacebookAuthProvider.credential(loginResult.accessToken!.tokenString);
//
//         // تسجيل الدخول باستخدام FirebaseAuth
//         final userCredential = await FirebaseAuth.instance.signInWithCredential(facebookAuthCredential);
//
//         emit(AuthFacebookSuccess(userCredential));
//       } else {
//         emit(AuthFacebookFailure('Facebook login failed'));
//       }
//     } catch (e) {
//       emit(AuthFacebookFailure(e.toString()));
//     }
//   }
//


  bool isPassword = true;
  IconData subfix = Icons.visibility_off;
  void changIconPassword() {
    isPassword = !isPassword;
    subfix = isPassword ? Icons.visibility_off : Icons.visibility;
    emit(ChangeIconPasswordSuccess());
  }

  
  
  
  
}
