class ProductModel {
  List<Products>? products;

  ProductModel({this.products});

  ProductModel.fromJson(Map<String, dynamic> json) {
    if (json['Products'] != null) {
      products = <Products>[];
      json['Products'].forEach((v) {
        products!.add(new Products.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.products != null) {
      data['Products'] = this.products!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Products {
  String? productCode;
  String? barCode;
  int? colorID;
  Null? colorArName;
  Null? colorEnName;
  int? sizeID;
  Null? sizeName;
  Null? sizeEName;
  String? productArName;
  String? productEnName;
  String? categoryId;
  String? categoryCode;
  String? categoryArName;
  String? categoryEnName;
  int? departmentId;
  Null? departmentArName;
  Null? departmentEnName;
  int? descriptionID;
  Null? descriptionArName;
  Null? descriptionEnName;
  int? seasonID;
  Null? seasonArName;
  Null? seasonEnName;
  Null? brandID;
  Null? brandArName;
  Null? brandEnName;
  int? countryID;
  Null? countryArName;
  Null? countryEnName;
  int? patternId;

  Null? patternArName;
  Null? patternEnName;
  int? stockQuantity;
  double? price;
  double? priceAfterDiscount;
  int? wholePrice;
  int? halfWholePrice;
  int? salePrice;
  int? lastBuyPrice;
  int? localCost;
  Null? exportPrice;

  Products(
      {this.productCode,
        this.barCode,

        this.colorID,
        this.colorArName,
        this.colorEnName,
        this.sizeID,
        this.sizeName,
        this.sizeEName,
        this.productArName,
        this.productEnName,
        this.categoryId,
        this.categoryCode,
        this.categoryArName,
        this.categoryEnName,
        this.departmentId,
        this.departmentArName,
        this.departmentEnName,
        this.descriptionID,
        this.descriptionArName,
        this.descriptionEnName,
        this.seasonID,
        this.seasonArName,
        this.seasonEnName,
        this.brandID,
        this.brandArName,
        this.brandEnName,
        this.countryID,
        this.countryArName,
        this.countryEnName,
        this.patternId,
        this.patternArName,
        this.patternEnName,
        this.stockQuantity,
        this.price,
        this.priceAfterDiscount,
        this.wholePrice,
        this.halfWholePrice,
        this.salePrice,
        this.lastBuyPrice,
        this.localCost,
        this.exportPrice,

      });

  Products.fromJson(Map<String, dynamic> json) {
    productCode = json['ProductCode'];
    barCode = json['BarCode'];
    colorID = json['ColorID'] != null ? json['ColorID'] as int : null;
    colorArName = json['ColorArName'];
    colorEnName = json['ColorEnName'];
    sizeID = json['SizeID'] != null ? json['SizeID'] as int : null;
    sizeName = json['SizeName'];
    sizeEName = json['SizeEName'];
    productArName = json['ProductArName'];
    productEnName = json['ProductEnName'];
    categoryId = json['CategoryId'];
    categoryCode = json['CategoryCode'];
    categoryArName = json['CategoryArName'];
    categoryEnName = json['CategoryEnName'];
    departmentId = json['DepartmentId'] != null ? json['DepartmentId'] as int : null;
    departmentArName = json['DepartmentArName'];
    departmentEnName = json['DepartmentEnName'];
    descriptionID = json['DescriptionID'] != null ? json['DescriptionID'] as int : null;
    descriptionArName = json['DescriptionArName'];
    descriptionEnName = json['DescriptionEnName'];
    seasonID = json['SeasonID'] != null ? json['SeasonID'] as int : null;
    seasonArName = json['SeasonArName'];
    seasonEnName = json['SeasonEnName'];
    brandID = json['BrandID'];
    brandArName = json['BrandArName'];
    brandEnName = json['BrandEnName'];
    countryID = json['CountryID'] != null ? json['CountryID'] as int : null;
    countryArName = json['CountryArName'];
    countryEnName = json['CountryEnName'];
    patternId = json['PatternId'] != null ? json['PatternId'] as int : null;
    patternArName = json['PatternArName'];
    patternEnName = json['PatternEnName'];
    stockQuantity = json['StockQuantity'] != null ? json['StockQuantity'] as int : null;
    price = json['Price'] != null ? json['Price'] as double : null;
    priceAfterDiscount = json['PriceAfterDiscount'] != null ? json['PriceAfterDiscount'] as double : null;
    wholePrice = json['WholePrice'] != null ? json['WholePrice'] as int : null;
    halfWholePrice = json['HalfWholePrice'] != null ? json['HalfWholePrice'] as int : null;
    salePrice = json['SalePrice'] != null ? json['SalePrice'] as int : null;
    lastBuyPrice = json['LastBuyPrice'] != null ? json['LastBuyPrice'] as int : null;
    localCost = json['LocalCost'] != null ? json['LocalCost'] as int : null;
    exportPrice = json['ExportPrice'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ProductCode'] = this.productCode;
    data['BarCode'] = this.barCode;


    data['ColorID'] = this.colorID;
    data['ColorArName'] = this.colorArName;
    data['ColorEnName'] = this.colorEnName;
    data['SizeID'] = this.sizeID;
    data['SizeName'] = this.sizeName;
    data['SizeEName'] = this.sizeEName;
    data['ProductArName'] = this.productArName;
    data['ProductEnName'] = this.productEnName;
    data['CategoryId'] = this.categoryId;
    data['CategoryCode'] = this.categoryCode;
    data['CategoryArName'] = this.categoryArName;
    data['CategoryEnName'] = this.categoryEnName;
    data['DepartmentId'] = this.departmentId;
    data['DepartmentArName'] = this.departmentArName;
    data['DepartmentEnName'] = this.departmentEnName;
    data['DescriptionID'] = this.descriptionID;
    data['DescriptionArName'] = this.descriptionArName;
    data['DescriptionEnName'] = this.descriptionEnName;
    data['SeasonID'] = this.seasonID;
    data['SeasonArName'] = this.seasonArName;
    data['SeasonEnName'] = this.seasonEnName;
    data['BrandID'] = this.brandID;
    data['BrandArName'] = this.brandArName;
    data['BrandEnName'] = this.brandEnName;
    data['CountryID'] = this.countryID;
    data['CountryArName'] = this.countryArName;
    data['CountryEnName'] = this.countryEnName;
    data['PatternId'] = this.patternId;
    data['PatternArName'] = this.patternArName;
    data['PatternEnName'] = this.patternEnName;
    data['StockQuantity'] = this.stockQuantity;
    data['Price'] = this.price;
    data['PriceAfterDiscount'] = this.priceAfterDiscount;
    data['WholePrice'] = this.wholePrice;
    data['HalfWholePrice'] = this.halfWholePrice;
    data['SalePrice'] = this.salePrice;
    data['LastBuyPrice'] = this.lastBuyPrice;
    data['LocalCost'] = this.localCost;
    data['ExportPrice'] = this.exportPrice;
    return data;
  }
}