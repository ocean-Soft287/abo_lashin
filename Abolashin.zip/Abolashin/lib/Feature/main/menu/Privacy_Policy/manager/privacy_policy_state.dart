abstract class PrivacyPolicyState{}
class InitializePrivacyPolicy extends PrivacyPolicyState{}

class GetImagePrivacyPolicyLoading extends PrivacyPolicyState{}
class GetImagePrivacyPolicySuccess extends PrivacyPolicyState{}
class GetImagePrivacyPolicyError extends PrivacyPolicyState{}



