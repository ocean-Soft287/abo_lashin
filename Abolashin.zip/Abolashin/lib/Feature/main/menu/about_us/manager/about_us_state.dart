abstract class AboutUsState{}
class InitializeAboutUs extends AboutUsState{}

class GetImageAboutUsLoading extends AboutUsState{}
class GetImageAboutUsSuccess extends AboutUsState{}
class GetImageAboutUsError extends AboutUsState{}



