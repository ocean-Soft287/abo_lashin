// import 'package:tamara_flutter_sdk/tamara_checkout.dart';
// import 'package:tamara_flutter_sdk/tamara_sdk.dart';
// class TamaraDemoPage extends StatelessWidget {
//   final String authToken = "YOUR_AUTH_TOKEN";
//   final String apiUrl = "YOUR_API_URL";
//   final String notificationWebHookUrl = "YOUR_NOTIFICATION_WEB_HOOK_URL";
//   final String publishKey = "YOUR_PUBLISH_KEY";
//   final String notificationToken = "YOUR_NOTIFICATION_TOKEN";
//
//   TamaraDemoPage({Key? key}) : super(key: key);
//
//   Future<void> initializeTamara() async {
//     await TamaraPayment.initialize(
//       authToken,
//       apiUrl,
//       notificationWebHookUrl,
//       publishKey,
//       notificationToken,
//       isSandbox: true, // استخدم true للتجربة
//     );
//   }
//
//   Future<void> createOrder() async {
//     await TamaraPayment.createOrder("123456", "This is a test order");
//     await TamaraPayment.setCustomerInfo(
//       "John",
//       "Doe",
//       "+1234567890",
//       "johndoe@example.com",
//       true,
//     );
//     await TamaraPayment.addItem(
//       "Test Item",
//       "001",
//       "SKU123",
//       "product",
//       100.0,
//       0.0,
//       0.0,
//       1,
//     );
//     await TamaraPayment.setShippingAddress(
//       "John",
//       "Doe",
//       "+1234567890",
//       "123 Test St.",
//       "",
//       "US",
//       "California",
//       "Los Angeles",
//     );
//     await TamaraPayment.paymentOrder(); // فتح صفحة الدفع
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Tamara SDK Demo")),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             ElevatedButton(
//               onPressed: () async {
//                 await initializeTamara();
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text("Tamara Initialized")),
//                 );
//               },
//               child: const Text("Initialize Tamara"),
//             ),
//             ElevatedButton(
//               onPressed: () async {
//                 await createOrder();
//               },
//               child: const Text("Create and Pay Order"),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }