import 'dart:convert';

import 'package:abolashin/Feature/main/menu/PreviousOrders/manager/previous_order_state.dart';


import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constans/constants.dart';
import '../../../../../core/network/remote/dioHelper.dart';
import '../../../../../core/network/remote/encrupt.dart';

import '../model/previous_order_model.dart';

class PreviousOrderCubit extends Cubit<PreviousOrderState> {
  PreviousOrderCubit() :super(InitializePreviousOrder());







  bool previousOrderLoading=true;
  List<PreviousOrdersModel> previousOrderList=[];
  void getPreviousOrders() {
    print(CustomerID);
    emit(GetPreviousOrderLoading());
    DioHelper.getData(url: 'api/Order/GetOrdersByCustomerID?CustomerID=$CustomerID').then((value) {
      print(value.data);
      print('الداتا بعد فك التشفير');
      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);
      List<dynamic> jsonList = jsonDecode(decryptedText);
      previousOrderList= jsonList.map((json) =>PreviousOrdersModel.fromJson(json)).toList();

      previousOrderLoading=false;
      emit(GetPreviousOrderSuccess());
    }).catchError((error) {
      print(
          'Error In Function Get Previous Orders This Error ${error.toString()}');
      emit(GetPreviousOrderError());
    });
  }

  }
