abstract class PreviousOrderState{}
class InitializePreviousOrder extends PreviousOrderState{}

class GetPreviousOrderLoading extends PreviousOrderState{}
class GetPreviousOrderSuccess extends PreviousOrderState{}
class GetPreviousOrderError extends PreviousOrderState{}