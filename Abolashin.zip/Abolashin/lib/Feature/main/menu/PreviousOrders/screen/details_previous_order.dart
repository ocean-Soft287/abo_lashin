import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../../core/constans/app_colors.dart';
import '../../../../../core/constans/constants.dart';
import '../../../../../core/network/local/chacheHelper.dart';



class DetailsPreviousOrder extends StatelessWidget {
  const DetailsPreviousOrder({super.key});

  @override
  Widget build(BuildContext context) {
    currentLang = CacheHelper.getData(key: 'changeLang') ?? 'ar';
    final currentLocale = context.locale;
    return Scaffold(
      backgroundColor: const Color(0xffF5F5F5),
      appBar: AppBar(

        elevation: 0,
        toolbarHeight: 40.0,
        backgroundColor: Colors.white,

        centerTitle: true,
        title: AutoSizeText(
          'previous_orders'.tr(),

          style: TextStyle(
            color: AppColors.mainAppColor,
            fontSize: 16.sp,
            fontWeight: FontWeight.w400,
            fontFamily: 'Madani',
          ),
        ),
      ),
      body: Column(

        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: 'order_number'.tr(),
                            style: TextStyle(
                              fontSize: 13.sp,
                              color: Colors.black,
                              fontWeight: FontWeight.w400,
                              fontFamily: 'Madani',
                            ),
                          ),
                          const WidgetSpan(
                            child: SizedBox(width: 4),
                          ),
                          TextSpan(
                            text: '12',
                            style: TextStyle(
                              fontSize: 14.sp,
                              color: AppColors.mainAppColor,
                              fontWeight: FontWeight.w400,
                              fontFamily: 'Madani',
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      'received'.tr(),
                      style: TextStyle(
                        color: const Color(0xff52A756),
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w400,
                        fontFamily: 'Madani',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'order_date'.tr(),
                        style: TextStyle(
                          fontSize: 13.sp,
                          color: Colors.red,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'Madani',
                        ),
                      ),
                      const WidgetSpan(
                        child: SizedBox(width: 8),
                      ),
                      TextSpan(
                        text: '12/8/202',
                        style: TextStyle(
                          fontSize: 16.sp,
                          color: AppColors.mainAppColor,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'Madani',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'delivery_address'.tr(),
                        style: TextStyle(
                          fontSize: 13.sp,
                          color: Colors.red,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'Madani',
                        ),
                      ),
                      const WidgetSpan(
                        child: SizedBox(width: 8),
                      ),
                      TextSpan(
                        text: 'الاسكندريه',
                        style: TextStyle(
                          fontSize: 16.sp,
                          color: AppColors.mainAppColor,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'Madani',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
              ],
            ),
          ),
          const Divider(
            height: 1,
            color: Color(0xff979797),
          ),
          Text(
            'products'.tr(),
            style: TextStyle(
              color: const Color(0xff52A756),
              fontSize: 16.sp,
              fontWeight: FontWeight.w400,
              fontFamily: 'Madani',
            ),
          ),
          const SizedBox(height: 10), // Add spacing if needed
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: SizedBox(

                  child: ListView.separated(
                    itemCount: 10,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          // Handle item tap here
                        },
                        child: SizedBox(
                          height: 100.h,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  spreadRadius: 2,
                                  blurRadius: 5,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: ClipRRect(
                                    child: CachedNetworkImage(
                                      width: MediaQuery.sizeOf(context).width,
                                      imageUrl: '',
                                      placeholder: (context, url) => Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: CircularProgressIndicator(
                                            value: 1.0,
                                            color: AppColors.mainAppColor,
                                          ),
                                        ),
                                      ),
                                      errorWidget: (context, url, error) => const Icon(Icons.error),
                                      fadeInDuration: const Duration(seconds: 1),
                                      height: 90.h,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 4.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Product Name',
                                          style: TextStyle(
                                            color: AppColors.mainAppColor,
                                            fontSize: 12.sp,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'Madani',
                                          ),
                                        ),
                                        SizedBox(height: 4.h),
                                        Text(
                                          'Description',
                                          style: TextStyle(
                                            color: Colors.red,
                                            fontSize: 8.sp,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'Madani',
                                          ),
                                        ),
                                        SizedBox(height: 4.h),
                                        RichText(
                                          text: TextSpan(
                                            children: [
                                              TextSpan(
                                                text: '${22 ?? 0}',
                                                style: TextStyle(
                                                  fontSize: 12.sp,
                                                  color: Colors.red,
                                                  fontWeight: FontWeight.w400,
                                                  fontFamily: 'Madani',
                                                ),
                                              ),
                                              TextSpan(
                                                text: ' price'.tr(),
                                                style: TextStyle(
                                                  fontSize: 8.sp,
                                                  color: AppColors.mainAppColor,
                                                  fontWeight: FontWeight.w400,
                                                  fontFamily: 'Madani',
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                    separatorBuilder: (context, index) {
                      return const SizedBox(height: 10);
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
