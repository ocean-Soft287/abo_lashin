import 'package:auto_size_text/auto_size_text.dart';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../../core/constans/app_colors.dart';
import '../../../../../core/constans/constants.dart';
import '../../../../../core/network/local/chacheHelper.dart';
import '../manager/previous_order_cubit.dart';
import '../manager/previous_order_state.dart';
import 'details_previous_order.dart';


class PreviousOrders extends StatelessWidget {
  const PreviousOrders({super.key});

  @override
  Widget build(BuildContext context) {
    currentLang = CacheHelper.getData(key: 'changeLang') ?? 'ar';
    final currentLocale = context.locale;
    return Scaffold(
      backgroundColor: const Color(0xffF5F5F5),
      appBar: AppBar(

        elevation: 0,
        toolbarHeight: 40.0,
        backgroundColor: Colors.white,

        centerTitle: true,
        title: AutoSizeText(
          'previous_orders'.tr(),

          style: TextStyle(
            color: AppColors.mainAppColor,
            fontSize: 16.sp,
            fontWeight: FontWeight.w400,
            fontFamily: 'Madani',
          ),
        ),
      ),
      body: BlocProvider(
        create: (context)=>PreviousOrderCubit()..getPreviousOrders(),
        child: BlocConsumer<PreviousOrderCubit,PreviousOrderState>(
          listener: (context,state)
          {},
          builder: (context,state)
          {
            PreviousOrderCubit previousOrderCubit=BlocProvider.of<PreviousOrderCubit>(context);
            return   Padding(
              padding: const EdgeInsets.all(8.0),
              child:
                  ListView.builder(
                      itemCount: previousOrderCubit.previousOrderList.length,
                      itemBuilder: (context,index)
                  {
                    return  InkWell(
                      onTap: (){
                        // navigato(context, const DetailsPreviousOrder());
                      },
                      child: SizedBox(
                        height: 145.h,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 8),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                spreadRadius: 2,
                                blurRadius: 5,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),

                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text:
                                          'order_number'.tr()
                                          ,
                                          style: TextStyle(
                                            fontSize: 13.sp,
                                            color: Colors.black,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'Madani',
                                          ),
                                        ),
                                        const WidgetSpan(
                                          child: SizedBox(width:4),
                                        ),
                                        TextSpan(
                                          text: '${previousOrderCubit.previousOrderList[index].orderNo??''}',
                                          style: TextStyle(
                                            fontSize: 14.sp,
                                            color: AppColors.mainAppColor,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'Madani',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Text(
                                  (previousOrderCubit.previousOrderList[index].underDeliver)?
                                    'received'.tr():'not_delivered'.tr(),
                                    style: TextStyle(
                                      color:  (previousOrderCubit.previousOrderList[index].underDeliver)? const Color(0xff52A756):Colors.red,
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: 'Madani',
                                    ),
                                  ),

                                ],
                              ),
                              const SizedBox(height: 4),
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text:
                                      'order_date'.tr()
                                      ,
                                      style: TextStyle(
                                        fontSize: 13.sp,
                                        color: Colors.red,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Madani',
                                      ),
                                    ),
                                    const WidgetSpan(
                                      child: SizedBox(width: 8),
                                    ),
                                    TextSpan(
                                      text: DateFormat('dd/MM/yyyy').format(previousOrderCubit.previousOrderList[index].orderDate),
                                      style: TextStyle(
                                        fontSize: 16.sp,
                                        color: AppColors.mainAppColor,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Madani',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 4),
                              RichText(
                                text: TextSpan(
                                  children: [

                                    TextSpan(
                                      text:
                                      'delivery_address'.tr()
                                      ,
                                      style: TextStyle(
                                        fontSize: 13.sp,
                                        color: Colors.red,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Madani',
                                      ),
                                    ),
                                    const WidgetSpan(
                                      child: SizedBox(width: 8),
                                    ),
                                    TextSpan(
                                      text:  previousOrderCubit.previousOrderList[index].customerAddress??'',
                                      style: TextStyle(
                                        fontSize: 16.sp,
                                        color: AppColors.mainAppColor,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Madani',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 4),

                              const Divider(
                                height: 1,
                                color: Color(0xff979797),
                              ),
                              5.verticalSpace,
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text:
                                        'total_price'.tr()
                                        ,
                                        style: TextStyle(
                                          fontSize: 11.sp,
                                          color: Colors.black,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: 'Madani',
                                        ),
                                      ),
                                      const WidgetSpan(
                                        child: SizedBox(width:4),
                                      ),
                                      TextSpan(
                                        text: previousOrderCubit.previousOrderList[index].finalValue.toString()??'',
                                        style: TextStyle(
                                          fontSize:16.sp,
                                          color:Colors.red,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: 'Madani',
                                        ),
                                      ),
                                      const WidgetSpan(
                                        child: SizedBox(width:4),
                                      ),
                                      TextSpan(
                                        text: 'price'.tr(),
                                        style: TextStyle(
                                          fontSize: 8.sp,
                                          color: AppColors.mainAppColor,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: 'Madani',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),



                            ],
                          ),
                        ),
                      ),
                    );
                  }
                  )



            );
          },

        ),
      ),
    );
  }
}
