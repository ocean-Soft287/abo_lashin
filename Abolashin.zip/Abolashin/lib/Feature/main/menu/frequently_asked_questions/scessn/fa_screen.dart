import 'package:auto_size_text/auto_size_text.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../core/constans/app_colors.dart';
import '../../../../../core/constans/constants.dart';
import '../../../../../core/network/local/chacheHelper.dart';
class FAQPage extends StatelessWidget {
final List<Map<String, String>> faqList = [
  {
    "question_ar": " ",
    "question_en": " ",
    "answer_ar": " ",
    "answer_en": " "
  },  {
    "question_ar": " ",
    "question_en": " ",
    "answer_ar": " ",
    "answer_en": " "
  },  {
    "question_ar": " ",
    "question_en": " ",
    "answer_ar": " ",
    "answer_en": " "
  },  {
    "question_ar": " ",
    "question_en": " ",
    "answer_ar": " ",
    "answer_en": " "
  },


];

@override
Widget build(BuildContext context) {
  currentLang = CacheHelper.getData(key: 'changeLang')??'ar';
  final currentLocale = context.locale;
  return Scaffold(
    backgroundColor: const Color(0xffF5F5F5),
    appBar: AppBar(

      elevation: 0,
      toolbarHeight: 40.0,
      backgroundColor: Colors.white,

      centerTitle: true,
      title: AutoSizeText(
        'frequently_asked_questions'.tr(),

     style: GoogleFonts.alexandria(
          color: AppColors.mainAppColor,
          fontSize: 16.sp,
          fontWeight: FontWeight.w400,

        ),
      ),
    ),
    body: ListView.builder(
      itemCount: faqList.length,
      itemBuilder: (context, index) {
        return Card(
          color: Colors.white,
          margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
          child: ExpansionTile(

            title: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${index+1}. '),
                Expanded(
                  child: Text(
                    (currentLocale.languageCode == 'ar')?
                    faqList[index]['question_ar'].toString() :
                    '${faqList[index]['question_en']}'
                    ,
                    style: GoogleFonts.alexandria(
                      color: AppColors.mainAppColor,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(
                  (currentLocale.languageCode == 'ar')?
                  faqList[index]['answer_ar'].toString() :
                  '${faqList[index]['answer_en']}'
                  ,
                  style: GoogleFonts.alexandria(
                    color: Colors.black,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w300,
                  ),
                ),
              ),
            ],
          ),
        );

      },
    ),
  );
}
}