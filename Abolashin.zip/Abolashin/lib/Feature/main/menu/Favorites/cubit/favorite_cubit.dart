import 'dart:convert';

import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/constans/constants.dart';
import '../../../../../core/network/remote/dioHelper.dart';
import '../../../../../core/network/remote/encrupt.dart';
import '../../../../../core/network/remote/end_point.dart';
import '../model/favorite_model.dart';
import 'favorite_state.dart';

class FavoriteCubit extends Cubit<FavoriteState> {
  FavoriteCubit() :super(InitializeFavorite());


  int pageNumberFavorite = 1;
  bool favoriteLoading = true;
  List<FavoriteModel> favoriteList = [];

  void getFavoriteCategory({bool fromPagination = false}) {
    if (fromPagination) {

    }
    else {
      emit(GetFavoriteLoading());
    }


    DioHelper.getData(
        url: '/api/Customer/GetCustomerProductsByID?CustomerID=$CustomerID')
        .then((value) {
      print(value.data);
      print('الداتا بعد فك التشفير');
      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);

      List<dynamic> jsonList = jsonDecode(decryptedText);

      favoriteLoading = false;
      pageNumberFavorite++;
      favoriteList.addAll(jsonList.map((json) => FavoriteModel.fromJson(json)));
      emit(GetFavoriteSuccess());
    }).catchError((error) {
      print(
          'Error In Function Get Favorite This Error ${error.toString()}');
      emit(GetFavoriteError());
    });
  }


  void addFavorite({required int productId, required Map<int, bool> favorite}) {
    print(favorite[productId] = !favorite[productId]!);
    favorite[productId] = !favorite[productId]!;
    print(favorite[productId] = !favorite[productId]!);
    emit(AddFavoriteLoading());

    String encryptedData = encryptData(
        {"ProductID": productId, "CustomerID": CustomerID},
        privateKey, publicKey);
    print("Encrypted Data: $encryptedData");
    String jsonData = jsonEncode(encryptedData);

    DioHelper.postData(url: '/api/Customer/AddCustomerProduct', data: jsonData)
        .then((value) {
      print('Success');
      print('الداتا قبل فك التشفير');
      print(value.data);

      print('الداتا بعد فك التشفير');
      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);
      emit(AddFavoriteSuccess());
    }).catchError((error) {
      favorite[productId] = !favorite[productId]!;
      emit(AddFavoriteError());
      print('is Error == $error');
      print('Error in Add Favorite ');
    }
    );
  }


  void deleteFavorite({required int productId, required int index}) {
    // print(favorite[productId] =!favorite[productId]!);
    // favorite[productId] =!favorite[productId]!;
    // print(favorite[productId] =!favorite[productId]!);
    emit(DeleteFavoriteLoading());
    print(productId);


    DioHelper.deleteData(
        url: '/api/Customer/DeleteCustomerProductBYID?CustomerID=$CustomerID&ProductID=$productId')
        .then((value) {
      print('Success');
      print('الداتا قبل فك التشفير');
      print(value.data);

      print('الداتا بعد فك التشفير');
      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);

      favoriteList.removeAt(index);
      emit(DeleteFavoriteSuccess());
    }).catchError((error) {
      // favorite[productId] =!favorite[productId]!;
      emit(DeleteFavoriteError());
      print('is Error == $error');
      print('Error in Add Favorite ');
    }
    );
  }


  void toggleFavorite(
      {required int productId, required Map<int, bool> favorite}) {
    if (favorite[productId] = false) {
 print('ADDDDDDDDDDDD');
    }
    else {
   print('delete');
    }
  }










}