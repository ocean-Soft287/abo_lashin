import 'package:abolashin/Feature/main/Add%20Order/manager/add_order_state.dart';
import 'package:abolashin/Feature/main/Add%20Order/screen/add_order_screen.dart';
import 'package:abolashin/Feature/main/cart/screen/widget/cart_widget.dart';
import 'package:abolashin/core/sharde/widget/navigation.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constans/app_assets.dart';
import '../../../../core/constans/app_colors.dart';
import '../../../../core/constans/constants.dart';
import '../../../../core/network/local/chacheHelper.dart';
import '../../../../core/sharde/widget/default_button.dart';
import '../../Add Order/manager/add_order_cubit.dart';
import '../../Add_New_Address/screen/add_new_address.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    currentLang = CacheHelper.getData(key: 'changeLang') ?? 'ar';
    final currentLocale = context.locale;

    return BlocProvider(
      create: (context) => AddOrderCubit()..getCustomerSalesBasket()..getAllAddress(),
      child: BlocBuilder<AddOrderCubit, AddOrderState>(
        builder: (context, state) {
          final addOrderCubit = BlocProvider.of<AddOrderCubit>(context);
          return Stack(alignment: Alignment.bottomCenter, children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      SvgPicture.asset(AppAssets.cartIcon, height: 60),
                      const SizedBox(width: 5),
                      Text(
                        'cart'.tr(),
                        style: GoogleFonts.alexandria(
                          textStyle: TextStyle(
                            fontSize: 24.sp,
                            fontWeight: FontWeight.w400,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        backgroundColor: Colors.white,
                        isScrollControlled: true,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.zero,
                        ),
                        builder: (context) {
                          return  CustomButtonSheet(addOrderCubit: addOrderCubit,);
                        },
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          vertical: 5, horizontal: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.white,
                      ),
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            AppAssets.locationIcon,
                            width: 30,
                            height: 30,
                          ),
                          const SizedBox(width: 20),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: 'delivery_to'.tr(),
                                      style: GoogleFonts.alexandria(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w400,
                                        color: AppColors.mainAppColor,
                                      ),
                                    ),
                    TextSpan(
                      text: addOrderCubit.allAddressList.isNotEmpty
                          ? addOrderCubit.allAddressList[ addOrderCubit.selectAddress]?.address ?? ''
                          : '',
                      style: GoogleFonts.alexandria(
                        fontSize: 8,
                        fontWeight: FontWeight.w400,
                        color: AppColors.mainAppColor,
                      ),
                    ),
                    ],
                  ),
                              ),
                              Text(
                                addOrderCubit.allAddressList?.isNotEmpty == true
                                    ?  addOrderCubit.allAddressList![ addOrderCubit.selectAddress]?.addressNotes ?? ''
                                    : '',
                                style: GoogleFonts.alexandria(
                                  textStyle: TextStyle(
                                    fontSize: 8,
                                    fontWeight: FontWeight.w400,
                                    color: AppColors.mainAppColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 25,
                            color: AppColors.secondAppColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: ConditionalBuilder(
                      condition: state is! GetCustomerSalesBasketLoading,
                      builder: (context) {
                        return ListView.separated(
                          itemCount:  addOrderCubit.salesBasketList.length,
                          itemBuilder: (context, index) {
                            return SizedBox(
                              height: 80.h,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 5, horizontal: 5),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.white,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      flex: 1,
                                      child:CachedNetworkImage(
                                        fit: BoxFit.cover,
                                        placeholder: (context, url) => Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Center(
                                            child: CircularProgressIndicator(
                                              value: 1.0,
                                              color: AppColors.mainAppColor,
                                            ),
                                          ),
                                        ),
                                        errorWidget: (context, url, error) => const Icon(Icons.error),
                                        imageUrl: BlocProvider.of<AddOrderCubit>(context)
                                            .salesBasketList[index].productImage??'',

                                      ),


                                    ),
                                    const SizedBox(width: 5),
                                    Expanded(
                                      flex: 2,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            (currentLocale.languageCode == 'ar')
                                                ?BlocProvider.of<AddOrderCubit>(context)
                                                        .salesBasketList[index]
                                                        .productName ??
                                                    ''
                                                : BlocProvider.of<AddOrderCubit>(context)
                                                        .salesBasketList[index]
                                                        .productEnName ??
                                                    '',
                                            maxLines: 1,
                                            style: GoogleFonts.alexandria(
                                              fontSize: 15.sp,
                                              fontWeight: FontWeight.w300,
                                              color: const Color(0xff313131),
                                            ),
                                          ),
                                          const Spacer(),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                  children: [
                                                    TextSpan(
                                                      text: (BlocProvider.of<AddOrderCubit>(context)
                                                          .salesBasketList[index]
                                                          .price ??
                                                          0.0)
                                                          .toStringAsFixed(2),
                                                      style: GoogleFonts.alexandria(
                                                        fontSize: 15.sp,
                                                        fontWeight: FontWeight.w400,
                                                        color: const Color(0xff313131),
                                                      ),
                                                    ),

                                                    TextSpan(
                                                      text: 'currency'.tr(),
                                                      style: GoogleFonts
                                                          .alexandria(
                                                        fontSize: 12,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: const Color(
                                                            0xff313131),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Row(
                                                children: [
                                                  GestureDetector(
                                                    onTap: () {
                                                      BlocProvider.of<AddOrderCubit>(context).subtractItemCart(index: index,quantity: 1, itemId: BlocProvider.of<AddOrderCubit>(context).salesBasketList[index].productID.toString(), );

                                                    },
                                                    child: Container(
                                                      width: 30.0,
                                                      height: 30.0,
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: Colors.grey[300],
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    0.2),
                                                            spreadRadius: 1,
                                                            blurRadius: 3,
                                                          ),
                                                        ],
                                                      ),
                                                      child: const Center(
                                                        child: Icon(
                                                          Icons.remove,
                                                          color: Colors.black,
                                                          size: 20.0,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(width: 10.0.w),
                                                  Text(
                                                    // '${salahOrderCubit.getQuantity("${salahOrderCubit.salesBasketList[index].productID}")??''}',
                                                    '${BlocProvider.of<AddOrderCubit>(context).getQuantity("${BlocProvider.of<AddOrderCubit>(context).salesBasketList[index].productID}") ?? ''}',

                                                    style: TextStyle(
                                                      fontSize: 18.0.sp,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontFamily: 'Madani',
                                                      color: const Color(
                                                          0xff707070),
                                                    ),
                                                  ),
                                                  SizedBox(width: 10.0.w),
                                                  GestureDetector(
                                                    onTap: () {
                                                      BlocProvider.of<AddOrderCubit>(context).addItemCart(
                                                          quantity: 1,
                                                          itemId: BlocProvider.of<AddOrderCubit>(context)
                                                              .salesBasketList[
                                                                  index]
                                                              .productID
                                                              .toString(),
                                                          price: double.parse(
                                                              BlocProvider.of<AddOrderCubit>(context)
                                                                  .salesBasketList[
                                                                      index]
                                                                  .price
                                                                  .toString()));
                                                    },
                                                    child: Container(
                                                      width: 30.0,
                                                      height: 30.0,
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: Colors.grey[300],
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    0.2),
                                                            spreadRadius: 1,
                                                            blurRadius: 3,
                                                          ),
                                                        ],
                                                      ),
                                                      child: const Center(
                                                        child: Icon(
                                                          Icons.add,
                                                          color: Colors.black,
                                                          size: 20.0,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),

                                  ],
                                ),
                              ),
                            );
                          },
                          separatorBuilder: (context, index) {
                            return const SizedBox(height: 5);
                          },
                        );
                      },
                      fallback: (context) {
                        return const SkeletonizerCart();
                      },
                    ),
                  )
                ],
              ),
            ),
            Container(
                color: const Color(0xffE7E7E7),
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text:
                                    BlocProvider.of<AddOrderCubit>(context).calculateTotalPrice().toStringAsFixed(2),
                                style: GoogleFonts.alexandria(
                                  fontSize: 20.sp,
                                  fontWeight: FontWeight.w400,
                                  color: const Color(0xff313131),
                                ),
                              ),
                              TextSpan(
                                text: 'currency'.tr(),
                                style: GoogleFonts.alexandria(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w400,
                                  color: const Color(0xff313131),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          'subtotal'.tr(),
                          style: GoogleFonts.alexandria(
                            textStyle: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w200,
                              color: Color(0xff313131),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.4,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        child: DefaultButton(
                       heightButton: 40,
                          text: 'complete_purchase'.tr(),
                          function: () {


                            if(BlocProvider.of<AddOrderCubit>(context).calculateTotalPrice()>=double.parse(addOrderCubit.allAddressList[addOrderCubit.selectAddress].billValue?.toString()??'0'))
                              {
                                navigato(context, AddOrderScreen(


                                  listItemName: addOrderCubit.salesBasketList,
                                  allAddressModel:  addOrderCubit.allAddressList[addOrderCubit.selectAddress],
                                  listItem: BlocProvider.of<AddOrderCubit>(context).items,total:BlocProvider.of<AddOrderCubit>(context).calculateTotalPrice() ,));
                                print(BlocProvider.of<AddOrderCubit>(context).items);


                                print(addOrderCubit.allAddressList[addOrderCubit.selectAddress].districtName);
                                print(addOrderCubit.salesBasketList);
                              }
                            else
                              {

                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      '${'minimum_order_value'.tr()} ${addOrderCubit.allAddressList[addOrderCubit.selectAddress].billValue ?? '0'}',
                                    ),
                                    backgroundColor: Colors.red,
                                    duration: const Duration(seconds: 3),
                                  ),
                                );

                              }



                          },
                          backgroundColor: AppColors.mainAppColor,
                        ),
                      ),
                    ),
                  ],
                ))
          ]);
        },
      ),
    );
  }
}



class CustomButtonSheet extends StatelessWidget {
  final addOrderCubit;
 CustomButtonSheet({super.key,required this.addOrderCubit});

  @override
  Widget build(BuildContext context) {
    addOrderCubit.getAllAddress();
    return BlocBuilder<AddOrderCubit,AddOrderState>(
      bloc: addOrderCubit,

      builder: (context,state)
      {

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          padding: const EdgeInsets.all(8),
          decoration: const BoxDecoration(
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment:
                MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      Text(
                        'choose_address'.tr(),
                        style: GoogleFonts.alexandria(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: Colors.black,
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          navigato(context, AddNewAddress());
                        //  print(addOrderCubit.allAddressList.length);
                        },
                        child: Text(
                          'add_new_address'.tr(),
                          style: GoogleFonts.alexandria(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(Icons.close,
                        color: AppColors.mainAppColor),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Divider(color: Colors.black, height: 2),
              const SizedBox(height: 20),
              Text(
                'existing_addressً'.tr(),
                style: GoogleFonts.alexandria(
                  textStyle: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.black,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              SizedBox(
                height: 200,
                child: ListView.separated(
                  itemCount:addOrderCubit.allAddressList.length,
                  itemBuilder: (context, index) {
                    return  InkWell(
                      onTap: ()
                      {
                        addOrderCubit.changeSelectedAddress(index);

                      },
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          color:(addOrderCubit.selectAddress==index)? const Color(0xffB5B7D0):Colors.white,
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(
                              color: AppColors.mainAppColor),
                        ),
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            Text(
                              addOrderCubit.allAddressList[index].addressNotes??'',
                              style: GoogleFonts.alexandria(
                                textStyle: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  color: AppColors.mainAppColor,
                                ),
                              ),
                            ),
                            Text(
                              addOrderCubit.allAddressList[index].arabicName??'',
                              style: GoogleFonts.alexandria(
                                textStyle: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  color: AppColors.mainAppColor,
                                ),
                              ),
                            ),
                            Text(
                              addOrderCubit.allAddressList[index].customerPhone??'',
                              style: GoogleFonts.alexandria(
                                textStyle: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  color: AppColors.mainAppColor,
                                ),
                              ),
                            ),
                            Text(
                              addOrderCubit.allAddressList[index].address??'',
                              style: GoogleFonts.alexandria(
                                textStyle: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  color: AppColors.mainAppColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (context,index)
                  {
                    return const SizedBox(height: 15,);
                  },
                ),
              )

            ],
          ),
        );
      },

    );
  }
}

