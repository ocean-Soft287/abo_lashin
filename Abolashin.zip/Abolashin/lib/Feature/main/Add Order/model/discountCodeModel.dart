class DiscountCodeModel {
  int? iD;
  String? discountCode;
  double? discountValue;
  int? discountPercent;
  String? fromDate;
  String? toDate;

  DiscountCodeModel(
      {this.iD,
        this.discountCode,
        this.discountValue,
        this.discountPercent,
        this.fromDate,
        this.toDate});

  DiscountCodeModel.fromJson(Map<String, dynamic> json) {
    iD = json['ID'];
    discountCode = json['DiscountCode'];
    discountValue = json['DiscountValue'];
    discountPercent = json['DiscountPercent'];
    fromDate = json['FromDate'];
    toDate = json['ToDate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ID'] = this.iD;
    data['DiscountCode'] = this.discountCode;
    data['DiscountValue'] = this.discountValue;
    data['DiscountPercent'] = this.discountPercent;
    data['FromDate'] = this.fromDate;
    data['ToDate'] = this.toDate;
    return data;
  }
}