class SalesBasket {
  int? customerID;
  String? customerName;
  String? customerEName;
  int? productID;
  String? productCode;
  String? productName;
  String? productEnName;
  int? salesQuantity;
  String? barCode;
  String? customerPhone;
  String? specifications; // Changed from Null? to String?
  int? discountPercent;
  String? productImage;
  double? stockQuantity;
  double? price;
  double? customerQuantity;
  double? totalQuantity;
  int? requiredQTY;
  int? giftQTY;
  int? yGiftQty;

  SalesBasket(
      {this.customerID,
        this.customerName,
        this.customerEName,
        this.productID,
        this.productCode,
        this.productName,
        this.productEnName,
        this.salesQuantity,
        this.barCode,
        this.customerPhone,
        this.specifications,
        this.discountPercent,
        this.productImage,
        this.stockQuantity,
        this.price,
        this.customerQuantity,
        this.totalQuantity,
        this.requiredQTY,
        this.giftQTY,
        this.yGiftQty});

  SalesBasket.fromJson(Map<String, dynamic> json) {
    customerID = json['CustomerID'];
    customerName = json['CustomerName'];
    customerEName = json['CustomerEName'];
    productID = json['ProductID'];
    productCode = json['ProductCode'];
    productName = json['ProductName'];
    productEnName = json['ProductEnName'];
    salesQuantity = json['SalesQuantity'];
    barCode = json['BarCode'];
    customerPhone = json['CustomerPhone'];
    specifications = json['Specifications']; // Now this can hold a String or null
    discountPercent = json['DiscountPercent'];
    productImage = json['ProductImage'];
    stockQuantity = json['StockQuantity'];
    price = json['Price'];
    customerQuantity = json['CustomerQuantity'];
    totalQuantity = json['TotalQuantity'];
    requiredQTY = json['RequiredQTY'];
    giftQTY = json['GiftQTY'];
    yGiftQty = json['Y_Gift_Qty'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['CustomerID'] = this.customerID;
    data['CustomerName'] = this.customerName;
    data['CustomerEName'] = this.customerEName;
    data['ProductID'] = this.productID;
    data['ProductCode'] = this.productCode;
    data['ProductName'] = this.productName;
    data['ProductEnName'] = this.productEnName;
    data['SalesQuantity'] = this.salesQuantity;
    data['BarCode'] = this.barCode;
    data['CustomerPhone'] = this.customerPhone;
    data['Specifications'] = this.specifications;
    data['DiscountPercent'] = this.discountPercent;
    data['ProductImage'] = this.productImage;
    data['StockQuantity'] = this.stockQuantity;
    data['Price'] = this.price;
    data['CustomerQuantity'] = this.customerQuantity;
    data['TotalQuantity'] = this.totalQuantity;
    data['RequiredQTY'] = this.requiredQTY;
    data['GiftQTY'] = this.giftQTY;
    data['Y_Gift_Qty'] = this.yGiftQty;
    return data;
  }
}
