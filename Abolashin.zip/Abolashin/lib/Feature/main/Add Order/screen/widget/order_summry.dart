import 'package:abolashin/Feature/main/Home/home_screen.dart';
import 'package:abolashin/Feature/main/Home/manager/home_cubit.dart';
import 'package:abolashin/core/constans/app_colors.dart';
import 'package:abolashin/core/sharde/widget/navigation.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../core/sharde/widget/default_button.dart';
import '../../model/add_item.dart';
import '../../model/order_summry_model.dart';
import '../../model/sales_basket.dart';
class OrderSummery extends StatelessWidget {
  List<SalesBasket>  listItemName;
  OrderSummryModel orderSummryModel;
 OrderSummery({super.key,required this.orderSummryModel,required this.listItemName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: SingleChildScrollView(
          child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
            children: [
          
              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 12),
                  decoration: BoxDecoration(
                      color: AppColors.mainAppColor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Text('order_success'.tr(), style: GoogleFonts.alexandria(
                    color: Colors.white,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w400,
          
                  ), ),
                ),
              ),
              20.verticalSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'invoice_number'.tr(),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                        TextSpan(
                          text: ' : ', // Adding a space manually
                          style: TextStyle(
                            fontSize: 16.sp,
                          ),
                        ),
                        TextSpan(
                          text: '12',
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'date'.tr(),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                        TextSpan(
                          text: ' : ', // Adding a space manually
                          style: TextStyle(
                            fontSize: 16.sp,
                          ),
                        ),
                        TextSpan(
                          text: orderSummryModel.orderDate,
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
          
              10.verticalSpace,
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'payment_method'.tr(),
                      style: GoogleFonts.alexandria(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w400,
                          color: Colors.black
                      ),
                    ),
                    TextSpan(
                      text:'cash_on_delivery'.tr(),
                      style: GoogleFonts.alexandria(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w300,
                        color: AppColors.mainAppColor,
                      ),
                    ),
                  ],
                ),
              ),
          
              10.verticalSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'total_quantity'.tr(),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                        TextSpan(
                          text: ' : ', // Adding a space manually
                          style: TextStyle(
                            fontSize: 16.sp,
                          ),
                        ),
                        TextSpan(
                          text: '${orderSummryModel.orderItems.length}',
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'total'.tr(),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                        TextSpan(
                          text: ' : ', // Adding a space manually
                          style: TextStyle(
                            fontSize: 16.sp,
                          ),
                        ),
                        TextSpan(
                          text: orderSummryModel.totalValue.toStringAsFixed(2),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
          
              10.verticalSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'discount'.tr(),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w400,
                            color: Colors.black
                          ),
                        ),
                        TextSpan(
                          text: ' : ', // Adding a space manually
                          style: TextStyle(
                            fontSize: 16.sp,
                          ),
                        ),
                        TextSpan(
                          text:  orderSummryModel.discount.toStringAsFixed(3),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ],
                    ),
                  ),

                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'final_price'.tr(),
                          style: GoogleFonts.alexandria(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w400,
                              color: Colors.black
                          ),
                        ),
                        TextSpan(
                          text: ' : ', // Adding a space manually
                          style: TextStyle(
                            fontSize: 16.sp,
                          ),
                        ),
                        TextSpan(
                          text: orderSummryModel.finalValue.toStringAsFixed(3),
                          style: GoogleFonts.alexandria(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w300,
                            color: AppColors.mainAppColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
          


              20.verticalSpace,
              Container(
                color: AppColors.mainAppColor,
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: Text(
                        'item_name'.tr(),
                        style: GoogleFonts.alexandria(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        'الكميه',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.alexandria(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        'unit_price'.tr(),
                        textAlign: TextAlign.center,
                        style: GoogleFonts.alexandria(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Text(
                        'total'.tr(),
                        textAlign: TextAlign.center,
                        style: GoogleFonts.alexandria(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          
              SizedBox(
                height: MediaQuery.sizeOf(context).height*.4,
                child: ListView.builder(

                  itemCount:listItemName.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5.0),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: Text(

                              '${listItemName[index].productName}',
                          maxLines: 2,
                              style: GoogleFonts.alexandria(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Text(
                              '${orderSummryModel.orderItems[index].quantity}',

                              textAlign: TextAlign.center,
                              style: GoogleFonts.alexandria(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black,

                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Text(
                              '${orderSummryModel.orderItems[index].price}',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.alexandria(
                                fontSize:12.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Text(
                              (orderSummryModel.orderItems[index].price*orderSummryModel.orderItems[index].quantity).toStringAsFixed(2),
                              textAlign: TextAlign.center,
                              style: GoogleFonts.alexandria(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w400,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
          
            40.verticalSpace,
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: DefaultButton(function: (){

                 BlocProvider.of<HomeCubit>(context).changeSelectIndexBottom(index: 0);
                 navigatofinsh(context,const HomeScreen(), false);



// navigato(context, OrderSummery());

                },text: 'home_page'.tr(),),
              )
          
          
          
            ],
          ),
        ),
      )),
    );
  }
}
