import 'package:abolashin/Feature/main/Add%20Order/model/all_address_model.dart';
import 'package:abolashin/Feature/main/Add%20Order/screen/widget/order_summry.dart';
import 'package:abolashin/core/sharde/widget/navigation.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';

import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constans/app_colors.dart';
import '../../../../core/constans/constants.dart';
import '../../../../core/network/local/chacheHelper.dart';
import '../../../../core/sharde/widget/default_button.dart';
import '../../../../core/sharde/widget/text_forn_field.dart';
import '../manager/add_order_cubit.dart';
import '../manager/add_order_state.dart';
import '../../Add_New_Address/model/area_model.dart';
import '../model/add_item.dart';
import '../model/sales_basket.dart';
import 'widget/dotted_divider_painter.dart';

class AddOrderScreen extends StatelessWidget {
  double total;
  double finalValue=0.0;
  dynamic listItem;
  AllAddressModel allAddressModel;
  List<SalesBasket>listItemName;
 AddOrderScreen({required this.listItemName,super.key,required this.total,required this.listItem,required this.allAddressModel});
  var keyForm = GlobalKey<FormState>();
  final codeActiveController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    currentLang = CacheHelper.getData(key: 'changeLang') ?? 'ar';
    final currentLocale = context.locale;

    return Scaffold(
      backgroundColor: const Color(0xffEFF2F7),
      appBar: AppBar(
        scrolledUnderElevation: 0,
        elevation: 0,
        toolbarHeight: 40.0,
        backgroundColor: Colors.white,

        centerTitle: true,
        title: AutoSizeText(
          'complete_order'.tr(),
          style: GoogleFonts.alexandria(
            color: AppColors.mainAppColor,
            fontSize: 16.sp,
            fontWeight: FontWeight.w400,

          ),
        ),
      ),
      body:Padding(
        padding: const EdgeInsets.all(12.0),
        child: SingleChildScrollView(
          child: Form(
            key: keyForm,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                5.verticalSpace,
                Text(
                  'do_you_have_discount_code'.tr(),
                  style: GoogleFonts.alexandria(
                    textStyle: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w400,
                      color:Colors.black,
                    ),
                  ),
                ),
                10.verticalSpace,
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                  ),
                  child:  Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: CustomTextFormField(
paddingN: 0,
                     borderColor: Colors.white,
                    fillColor: Colors.white,

                          hintText: 'enter_discount_code'.tr(),
                          textInputType: TextInputType.name,

                          validator: (value) {

                            if (value == null || value.isEmpty) {
                              return 'please_enter_discount_code'.tr();
                            }




                            return null;
                          },
                          controller: codeActiveController,



                        ),
                      ),
                      const SizedBox(width: 5,),
                      Expanded(
                        flex: 1,
                        child:

                        BlocConsumer<AddOrderCubit,AddOrderState>(
                          listener: (context,state)
                          {
                            if(state is GetDiscountError)
                              {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(

                                        'coupon_used_before'.tr()
                                    ),
                                    backgroundColor: Colors.red,
                                    duration: const Duration(seconds: 2),
                                  ),
                                );
                              }

                            if(state is GetDiscountSuccess)
                            {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(

                                      'discount_code_activated_successfully'.tr()
                                  ),
                                  backgroundColor: Colors.green,
                                  duration: const Duration(seconds: 2),
                                ),
                              );
                            }

                          },
                          builder: (context,state)
                          {
                            return  ConditionalBuilder(
                              condition:state is !GetDiscountLoading  ,
                              builder:(context){
                                return      DefaultButton(
                                  heightButton: 35,
                                  backgroundColor:AppColors.mainAppColor,
                                  text: 'activate'.tr(),function: (){
                                  if (keyForm.currentState!.validate()) {

                                     BlocProvider.of<AddOrderCubit>(context).getDiscount(codeDiscount: codeActiveController.text);
                                  }


                                },);
                              } ,
                              fallback:(context){
                                return Center(
                                  child: CircularProgressIndicator(
                                    color: AppColors.mainAppColor,
                                    strokeWidth: 1.0,
                                  ),
                                );

                              } ,

                            );
                          },

                        ),
                      ),
                    ],
                  ),
                ),
                20.verticalSpace,
                Text(
                  'payment_method'.tr(),
                  style: GoogleFonts.alexandria(
                    textStyle: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color:Colors.black,
                    ),
                  ),
                ),
                10.verticalSpace,
                Row(
                  children: [
                    Radio<bool>(
                      activeColor: AppColors.mainAppColor,
                      value: true,
                      groupValue: true,
                      onChanged: (value) {

                      },
                    ),
                    Text(
                      'cash_on_delivery'.tr(),
                      style: GoogleFonts.alexandria(
                        textStyle: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w400,
                          color:Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                40.verticalSpace,

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'subtotal'.tr(),
                          style: GoogleFonts.alexandria(
                            color:Colors.black,
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w400,

                          ),// Adjust the style as needed
                        ),
                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text:
                                total.toStringAsFixed(2)
                                ,
                                style: GoogleFonts.alexandria(
                                  fontSize: 13.sp,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w400,

                                ),
                              ),
                              const WidgetSpan(
                                child: SizedBox(width: 8),
                              ),
                              TextSpan(
                                text: 'currency'.tr(),
                                style: GoogleFonts.alexandria(
                                  fontSize: 8.sp,
                                  color: AppColors.mainAppColor,
                                  fontWeight: FontWeight.w400,

                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  4.verticalSpace,

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'delivery_fee'.tr(),
                          style: GoogleFonts.alexandria(
                            color:Colors.black,
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w400,

                          ),// Adjust the style as needed
                        ),
                        BlocBuilder<AddOrderCubit,AddOrderState>(
                          builder: (context,state)
                          {
                            return
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text:
                                      (double.tryParse(allAddressModel.deliveryValue.toString()) ?? 0.0).toStringAsFixed(2)


                                      ,
                                      style: GoogleFonts.alexandria(
                                        fontSize: 13.sp,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w400,

                                      ),
                                    ),
                                    const WidgetSpan(
                                      child: SizedBox(width: 8),
                                    ),
                                    TextSpan(
                                      text: 'currency'.tr(),
                                      style: GoogleFonts.alexandria(
                                        fontSize: 8.sp,
                                        color: AppColors.mainAppColor,
                                        fontWeight: FontWeight.w400,

                                      ),
                                    ),
                                  ],
                                ),
                              );
                          },

                        ),
                      ],
                    ),

                    4.verticalSpace,

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'discount_value'.tr(),
                          style: GoogleFonts.alexandria(
                            color:Colors.black,
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w400,

                          ),// Adjust the style as needed
                        ),
                        BlocBuilder<AddOrderCubit,AddOrderState>(
                          builder: (context,state)

                          {
                            return RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text:
                                    (double.tryParse(
                                      BlocProvider.of<AddOrderCubit>(context).discountList.isNotEmpty
                                          ? BlocProvider.of<AddOrderCubit>(context).discountList[0].discountValue.toString()
                                          : '0',
                                    ) ?? 0.0).toStringAsFixed(2)


                                    ,




                                    style: GoogleFonts.alexandria(
                                      fontSize: 13.sp,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,

                                    ),
                                  ),
                                  const WidgetSpan(
                                    child: SizedBox(width: 8),
                                  ),
                                  TextSpan(
                                    text: 'currency'.tr(),
                                    style: GoogleFonts.alexandria(
                                      fontSize: 8.sp,
                                      color: AppColors.mainAppColor,
                                      fontWeight: FontWeight.w400,

                                    ),
                                  ),
                                ],
                              ),
                            );
                          },

                        )
                      ],
                    ),
                    10.verticalSpace,
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: CustomPaint(
                        painter: DottedDividerPainter(),
                        child: Container(height: 1),
                      ),
                    ),

                   10.verticalSpace,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'total'.tr(),
                          style: GoogleFonts.alexandria(
                            color:Colors.black,
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w400,

                          ),// Adjust the style as needed
                        ),
                        BlocBuilder<AddOrderCubit,AddOrderState>(
                          builder: (context,state)
                          {
                            return   RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: BlocProvider.of<AddOrderCubit>(context).discountList.isEmpty
                                        ? (total + num.parse(allAddressModel.deliveryValue?.toString() ?? '0'))
                                        .toStringAsFixed(2)
                                        : (
                                        (total + (num.parse(allAddressModel.deliveryValue?.toString() ?? '0'))) -
                                            (double.tryParse(
                                              BlocProvider.of<AddOrderCubit>(context).discountList.isNotEmpty
                                                  ? BlocProvider.of<AddOrderCubit>(context).discountList[0].discountValue.toString()
                                                  : '0',
                                            ) ?? 0.0)
                                    ).toStringAsFixed(2),
                                    style: GoogleFonts.alexandria(
                                      fontSize: 13.sp,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,

                                    ),
                                  ),
                                  const WidgetSpan(
                                    child: SizedBox(width: 8),
                                  ),
                                  TextSpan(
                                    text: 'currency'.tr(),
                                    style: GoogleFonts.alexandria(
                                      fontSize: 8.sp,
                                      color: AppColors.mainAppColor,
                                      fontWeight: FontWeight.w400,

                                    ),
                                  ),
                                ],
                              ),
                            );
                          }
                        ),


                      ],
                    ),

                  ],
                ),


                50.verticalSpace,

                BlocConsumer<AddOrderCubit,AddOrderState>(
                  listener:  (context,state){
                    if(state is AddOrderSuccess)
                      {

                        Fluttertoast.showToast(
                          msg: 'order_success'.tr(),
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          timeInSecForIosWeb: 1,
                          backgroundColor: AppColors.mainAppColor,
                          textColor: Colors.white,
                          fontSize: 16.0,
                          webBgColor: "linear-gradient(to right, #00b09b, #96c93d)",
                          webPosition: "center",
                        );

                        navigatofinsh(context, OrderSummery(listItemName: listItemName,orderSummryModel:state.orderSummryModel! ,), false);

                      }
                    if(state is AddOrderError)
                    {
                        Fluttertoast.showToast(
                        msg: 'order_error'.tr(),
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.NONE,
                        timeInSecForIosWeb: 1,
                        backgroundColor:Colors.red,
                        textColor: Colors.white,
                        fontSize: 16.0,
                        webBgColor: "linear-gradient(to right, #00b09b, #96c93d)",
                        webPosition: "center",
                      );
                    }
                  },
                  builder: (context,state){

                    return ConditionalBuilder(

                        condition: state is !AddOrderLoading,

                        builder: (context)
                        {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: DefaultButton(function: (){


                          BlocProvider.of<AddOrderCubit>(context).addOrder

                            (
                              regionName:allAddressModel.regionName,
                              customerAddress:allAddressModel.addressNotes3.toString() ,
                              customName:allAddressModel.arabicName ,
                              districtName:allAddressModel.districtName2 ,
                              email:allAddressModel.email ,
                              listItem:listItem ,
                              total: total,
                              addition: num.parse(allAddressModel.deliveryValue?.toString() ?? '0'),
                              discount:BlocProvider.of<AddOrderCubit>(context).discountList.isEmpty?0.0:
                              BlocProvider.of<AddOrderCubit>(context).discountList[0].discountValue!.toDouble()



                          );



// navigato(context, OrderSummery());

                            },text: 'complete_order'.tr(),),
                          );
                        }
                        ,


                        fallback: (context)
                    {
                      return const Center(child: CircularProgressIndicator());
                    });
                  },

                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
