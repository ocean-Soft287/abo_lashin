
import 'dart:convert';

import 'package:abolashin/Feature/main/Home/manager/home_cubit.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';


import '../../../../core/constans/constants.dart';
import '../../../../core/network/remote/dioHelper.dart';
import '../../../../core/network/remote/encrupt.dart';
import '../../../../core/network/remote/end_point.dart';
import '../model/add_item.dart';
import '../../Add_New_Address/model/area_model.dart';
import '../model/all_address_model.dart';
import '../model/discountCodeModel.dart';
import '../model/order_summry_model.dart';
import '../model/sales_basket.dart';
import 'add_order_state.dart';

class AddOrderCubit extends Cubit<AddOrderState> {
  AddOrderCubit() :super(InitializeAddOrder());



  OrderSummryModel? orderSummryModel;
  void addOrder({
    required String customName,




    required double total,
    required dynamic listItem,
    required dynamic districtName,
    required dynamic regionName,
    required String email,
    required String customerAddress,
    required num addition,
    required num discount,


  })
  {

    emit(AddOrderLoading());
    {







    }

    String encryptedData = encryptData(
        {






          "OrderDate":DateFormat('yyyy-MM-dd','en').format(DateTime.now()),
          "DeliveryDate":DateFormat('yyyy-MM-dd','en').format(DateTime.now()),
          "CustomerPhone":customerPhone,
        "email":email,
        "OrderAddress":customerAddress,
           "DistrictName":"$districtName",
          "RegionName":"$regionName",

        "PayID":0,



        "Apartment":"10",


          "TotalValue":total,"Additions":addition,
          "Discount":discount,"FinalValue": ((total + (addition))-discount),
          "OnlineStoreId":-1,"DiscountCardValue":0,


        "_OrderItems":listItem.map((item) => item.toMap()).toList()

        },
        privateKey, publicKey);
    print("Encrypted Data: $encryptedData");

    final decryptedText = decrypt(encryptedData, privateKey, publicKey);
   print(decryptedText);
    orderSummryModel=OrderSummryModel.fromJson(jsonDecode(decryptedText));

    String jsonData = jsonEncode(encryptedData);

    DioHelper.postData(url:'/api/Order' , data:jsonData).then((value){
      print(value.data);
      print('Success Order');
      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);

      emit(AddOrderSuccess(orderSummryModel));
    }).catchError((error){

      print('This is Error in Add Order $error');
      emit(AddOrderError(error.toString()));
    });

  }




















  int pageNumberSalesBasket = 1;
  bool salesBasketLoading = true;
  List<SalesBasket> salesBasketList = [];

  void getCustomerSalesBasket({bool fromPagination = false}) {
    items.clear();
    if (fromPagination) {

    }
    else {
      emit(GetCustomerSalesBasketLoading());
    }


    DioHelper.getData(
        url: '/api/Product/GetCustomerSalesBasket?CustomerID=$CustomerID')
        .then((value) {
      print(value.data);
      print('الداتا بعد فك التشفير');
      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);

      List<dynamic> jsonList = jsonDecode(decryptedText);

      salesBasketLoading  = false;
      pageNumberSalesBasket++;
      salesBasketList.addAll(jsonList.map((json) => SalesBasket.fromJson(json)));

      for (var item in salesBasketList) {
        final newItem = CartItem(quantity:int.parse(item.salesQuantity.toString()), itemId: item.productID.toString(), price:double.parse(item.price.toString()));
        items.add(newItem);
      }
      emit(GetCustomerSalesBasketSuccess());
    }).catchError((error) {
      print(
          'Error In Function Get Customer Sales Basket This Error ${error.toString()}');
      emit(GetCustomerSalesBasketError());
    });
  }


  void addItem({
    required dynamic productId,
    context



  })
  {

    emit(AddItemSalesBasketLoading());
    {







    }
    String encryptedData = encryptData(
        {



          "CustomerID":CustomerID,
          "ProductID" :productId
        },
        privateKey, publicKey);
    print("Encrypted Data: $encryptedData");
    final decryptedText = decrypt(encryptedData, privateKey, publicKey);
    print(decryptedText);

    String jsonData = jsonEncode(encryptedData);

    DioHelper.postData(url:'/api/Product/AddSalesBasket' , data:jsonData).then((value){
      print(value.data);

      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);
      getQuitity();
     // BlocProvider.of<HomeCubit>(context).addItem(productId: productId, quantity: 1, isVisibility: true);
      emit(AddItemSalesBasketSuccess());
    }).catchError((error){

      print('This is Error in Add Item $error');
      emit(AddItemSalesBasketError());
    });

  }


  void decreaseItem({
    required dynamic productId,



  })
  {

    emit(DecreaseSalesBasketLoading());
    {







    }


    DioHelper.deleteData(url:'/api/Product/DeleteSalesBasket?CustomerID=$CustomerID&ProductId=$productId' ,).then((value){
      print(value.data);

      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);

      emit(DecreaseSalesBasketSuccess());
    }).catchError((error){

      print('This is Error in Decrease Item $error');
      emit(DecreaseSalesBasketError());
    });

  }

  List<CartItem> items = [];

  void addItemCart({required int quantity, required String itemId, required double price}) {

    bool itemFound = false;

    for (var item in items) {
      if (item.itemId == itemId) {

        item.quantity += quantity;
         emit(AddItemInCart());
        addItem(productId: item.itemId);
        itemFound = true;
        break;
      }
    }


    if (!itemFound) {
      final newItem = CartItem(quantity: quantity, itemId: itemId, price: price);
      items.add(newItem);
      emit(AddItemInCart());
    }
  }


  void printCart() {
    if (items.isEmpty) {
      print("سلة التسوق فارغة!");
      return;
    }

    for (var item in items) {
      print("ID: ${item.itemId}, الكمية: ${item.quantity}, السعر: ${item.price}");
    }
  }


  void subtractItemCart({required int quantity, required String itemId,required int index}) {
    for (var item in items) {
      if (item.itemId == itemId) {

        item.quantity -= quantity;


        if (item.quantity <= 0) {
          items.remove(item);
          salesBasketList.removeAt(index);


          emit(RemoveItemFromCart());
          decreaseItem(productId: itemId);
        } else {
          emit(SubtractItemFromCart());
          decreaseItem(productId: itemId);
        }
        return;
      }
    }
  }

  int getQuantity(String itemId) {
    for (var item in items) {
      if (item.itemId == itemId) {
        return item.quantity;
      }
    }
    return 1;
  }


  double totalPrice = 0.0;
  double calculateTotalPrice() {
   totalPrice = 0.0;

    for (var item in items) {
      totalPrice += item.quantity * item.price;
    }

    return totalPrice;
  }

  void getQuitity(){

    print(items);
    emit(ChangeQUtityCart());
  }



  List<dynamic> governoratesList = [];

  void getGovernorates() {

    emit(GetGovernoratesLoading());
    DioHelper.getData(url: Endpoints.governorates).then((value) {
      print(value.data);
      if (value.statusCode == 200) {
        final decryptedText = decrypt(value.data, privateKey, publicKey);
        print(decryptedText);


        List<dynamic> jsonList = jsonDecode(decryptedText);


        // mainCategoryList =
        //     jsonList.map((json) => MainCategoryModel.fromJson(json)).toList();


        emit(GetGovernoratesSuccess());
      } else {
        print('Failed with status code: ${value.statusCode}');
        emit(GetGovernoratesError());
      }
    }).catchError((error) {
      print(
          'Error In Function Get Governorates This Error ${error.toString()}');
      emit(GetGovernoratesError());
    });
  }







  List<AllAddressModel> allAddressList = [];
  void getAllAddress() {

    emit(GetGAllAddressLoading());
    DioHelper.getData(url: '/api/Customers/GetCustomerAddress?CustomerPhone=$customerPhone').then((value) {
      print(value.data);
      if (value.statusCode == 200) {
        final decryptedText = decrypt(value.data, privateKey, publicKey);
        print(decryptedText);


        List<dynamic> jsonList = jsonDecode(decryptedText);


        allAddressList =
            jsonList.map((json) => AllAddressModel.fromJson(json)).toList();

   print(allAddressList.length);
        emit(GetGAllAddressSuccess());
      } else {
        print('Failed with status code: ${value.statusCode}');
        emit(GetGAllAddressError());
      }
    }).catchError((error) {
      print(
          'Error In Function Get GAll Address This Error ${error.toString()}');
      emit(GetGAllAddressError());
    });
  }

  int selectAddress=0;
  void changeSelectedAddress(int index){
    selectAddress=index;
    emit(ChangeSelectedAddress());

  }




  List<DiscountCodeModel> discountList = [];
  void getDiscount({required var codeDiscount}) {

    emit(GetDiscountLoading());
    DioHelper.getData(url: Endpoints.couponsDiscountCode(codeDiscount)).then((value) {
      // print(value.data);
      if (value.statusCode == 200) {
        final decryptedText = decrypt(value.data, privateKey, publicKey);
       print(decryptedText);


        List<dynamic> jsonList = jsonDecode(decryptedText);


        discountList =
            jsonList.map((json) => DiscountCodeModel.fromJson(json)).toList();

        print(discountList);
        emit(GetDiscountSuccess());
      } else {
        print('Failed with status code: ${value.statusCode}');
        emit(GetDiscountError());
      }
    }).catchError((error) {
      print(error.toString());
      // print(
      //     'Error In Function Get Discount This Error ${error.toString()}');
      emit(GetDiscountError(error: error.toString()));
    });
  }


}