import 'package:abolashin/Feature/main/product_details/manager/product_details_state.dart';
import 'package:abolashin/core/constans/app_assets.dart';
import 'package:abolashin/core/constans/app_colors.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:skeletonizer/skeletonizer.dart';

import '../../../../core/constans/constants.dart';
import '../../../../core/network/local/chacheHelper.dart';
import '../../../../core/sharde/widget/default_button.dart';
import '../../../../core/sharde/widget/navigation.dart';
import '../../Add Order/manager/add_order_cubit.dart';
import '../../Home/manager/home_cubit.dart';
import '../../Home/manager/home_state.dart';
import '../../Home/widget/porduct_card.dart';
import '../../Search/screen/search_screen.dart';
import '../../category/manager/category_cubit.dart';
import '../../category/manager/category_state.dart';
import '../../menu/Favorites/cubit/favorite_cubit.dart';
import '../../menu/Favorites/cubit/favorite_state.dart';
import '../manager/product_details_cubit.dart';
class ProductDetailsScreen extends StatelessWidget {
  dynamic productId;
  dynamic categoryId;
 ProductDetailsScreen({super.key,required this.productId,required this.categoryId});

  @override
  Widget build(BuildContext context) {
    currentLang = CacheHelper.getData(key: 'changeLang')??'ar';
    final currentLocale = context.locale;
    return Scaffold(
      backgroundColor: AppColors.backgroundAppColor,
     appBar:  AppBar(
        title: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 1,vertical: 0),
          child: InkWell(
            onTap: () {
              navigato(context, const SearchScreen());
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(50),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'search'.tr(),
                    style: GoogleFonts.alexandria(
                      textStyle: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w400,
                        color: const Color(0xff6A6A6A),
                      ),
                    ),
                  ),
                  SvgPicture.asset(AppAssets.searchIcon),
                ],
              ),
            ),
          ),
        ),
       backgroundColor: AppColors.backgroundAppColor,
        elevation: 0,
       scrolledUnderElevation: 0,

      ),

      body:Stack(
        alignment: Alignment.bottomCenter,
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
              BlocProvider(
                create: (context)=>ProductDetailsCubit()..getProductDetails(productId: productId),
                child:
                BlocBuilder<ProductDetailsCubit,ProductDetailsState>(

                  builder: (context,state)
                      {ProductDetailsCubit productDetailsCubit=BlocProvider.of(context);
                        return

                          ConditionalBuilder(
                            condition: state is! GetProductDetailsLoading&&productDetailsCubit.productDetailsList.isNotEmpty,
                            builder:(context){
                              return Column(
                                children: [
                                  Container(
                                    color: Colors.white,
                                    padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 12),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [

                                       Stack(
                                          children: [
                                            CachedNetworkImage(

                                              width: MediaQuery.sizeOf(context).width,
                                              imageUrl:
                                              productDetailsCubit.productDetailsList?[0]?.productcImage?.toString()??'',
                                              placeholder: (context, url) => Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: Center(
                                                  child: CircularProgressIndicator(
                                                    value: 1.0,
                                                    color: AppColors.mainAppColor,
                                                  ),
                                                ),
                                              ),
                                              errorWidget: (context, url, error) => const Icon(Icons.error),
                                              fadeInDuration: const Duration(seconds: 1),
                                              height:200.h,

                                              fit: BoxFit.fill,
                                            ),

                                          ],
                                        ),
                                        const SizedBox(height: 20,),
                                        Text(
                                          (currentLocale.languageCode == 'ar')?
                                          productDetailsCubit.productDetailsList[0].productArName.toString()??''
:  productDetailsCubit.productDetailsList[0].productEnName.toString()??'',
                                          maxLines: 2,


                                          style: GoogleFonts.alexandria(
                                            textStyle: TextStyle(
                                              fontSize: 16.sp,

                                              fontWeight: FontWeight.w600,
                                              color:Colors.black,
                                            ),
                                          ),),
                                        const SizedBox(height: 10,),
                                        RichText(
                                            text: TextSpan(
                                                children: [
                                                  TextSpan(
                                                    text: (productDetailsCubit.productDetailsList[0].price ?? 0.0).toStringAsFixed(2),

                                                    style: GoogleFonts.alexandria(
                                                      fontSize: 16.sp,
                                                      fontWeight: FontWeight.w700,
                                                      color: AppColors.mainAppColor,
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: 'currency'.tr(),
                                                    style: GoogleFonts.alexandria(
                                                      fontSize: 16.sp,
                                                      fontWeight: FontWeight.w300,
                                                      color: AppColors.mainAppColor,
                                                    ),
                                                  )

                                                ])),
                                        const SizedBox(height: 20,),
                                        Text('description'.tr(),

                                          maxLines: 1,


                                          style: GoogleFonts.alexandria(
                                            textStyle: TextStyle(
                                              fontSize: 16.sp,

                                              fontWeight: FontWeight.w600,
                                              color:Colors.black,
                                            ),
                                          ),),
                                        const SizedBox(height: 10,),
                                        Text(

                                          productDetailsCubit.productDetailsList[0].specifications.toString()??'',
                                          maxLines: 5,


                                          style: GoogleFonts.alexandria(
                                            textStyle: TextStyle(
                                              fontSize: 13.sp,

                                              fontWeight: FontWeight.w300,
                                              color:Colors.black,
                                            ),
                                          ),),
                                      ],
                                    ),
                                  ),

                                ],

                              );
                            } ,
                            fallback: (context){
                              return Skeletonizer(
                                enabled: true,
                                child: Column(
                                  children: [
                                    Container(
                                      color: Colors.white,
                                      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 12),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Image.asset( AppAssets.appleTest2Icon, width: MediaQuery.sizeOf(context).width, height:200.h,

                                          ),
                                          // CachedNetworkImage(
                                          //
                                          //   width: MediaQuery.sizeOf(context).width,
                                          //   imageUrl:
                                          //  AppAssets.appleTestIcon,
                                          //   placeholder: (context, url) => Padding(
                                          //     padding: const EdgeInsets.all(8.0),
                                          //     child: Center(
                                          //       child: CircularProgressIndicator(
                                          //         value: 1.0,
                                          //         color: AppColors.mainAppColor,
                                          //       ),
                                          //     ),
                                          //   ),
                                          //   errorWidget: (context, url, error) => const Icon(Icons.error),
                                          //   fadeInDuration: const Duration(seconds: 1),
                                          //   height:200.h,
                                          //
                                          //   fit: BoxFit.fill,
                                          // ),
                                          const SizedBox(height: 20,),
                                          Text('تفاح اخضر مستورد 1كجم',

                                            maxLines: 2,


                                            style: GoogleFonts.alexandria(
                                              textStyle: TextStyle(
                                                fontSize: 16.sp,

                                                fontWeight: FontWeight.w600,
                                                color:Colors.black,
                                              ),
                                            ),),
                                          const SizedBox(height: 10,),
                                          RichText(
                                              text: TextSpan(
                                                  children: [
                                                    TextSpan(
                                                      text: '500.000',
                                                      style: GoogleFonts.alexandria(
                                                        fontSize: 16.sp,
                                                        fontWeight: FontWeight.w700,
                                                        color: AppColors.mainAppColor,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: 'currency'.tr(),
                                                      style: GoogleFonts.alexandria(
                                                        fontSize: 16.sp,
                                                        fontWeight: FontWeight.w300,
                                                        color: AppColors.mainAppColor,
                                                      ),
                                                    )

                                                  ])),
                                          const SizedBox(height: 20,),
                                          Text('الوصف',

                                            maxLines: 1,


                                            style: GoogleFonts.alexandria(
                                              textStyle: TextStyle(
                                                fontSize: 16.sp,

                                                fontWeight: FontWeight.w600,
                                                color:Colors.black,
                                              ),
                                            ),),
                                          const SizedBox(height: 10,),
                                          Text('استعد لتذوق الطعم اللذيذ لبطاطس القلي الهشة! مع طبيعتها المتعددة الاستخدامات وطعمها اللذيذ تعتبر بطاطس القلي مكوتا أساسيا في مطابخ العديد من الثقافات في جميع أنحاء العالم.',

                                            maxLines: 5,


                                            style: GoogleFonts.alexandria(
                                              textStyle: TextStyle(
                                                fontSize: 13.sp,

                                                fontWeight: FontWeight.w300,
                                                color:Colors.black,
                                              ),
                                            ),),
                                        ],
                                      ),
                                    ),

                                  ],

                                ),
                              );
                            } ,

                          );
                      }

                ),
              ),
                20.verticalSpace,
                Padding(
                  padding: const EdgeInsetsDirectional.only(
                    start: 16,

                  ),
                  child: BlocProvider(
                    create: (context)=>CategoryCubit()..getItemsForSubCategory(subCategoryId: categoryId),
                    child: BlocBuilder<CategoryCubit,CategoryState>(
                      builder: (context,state){
                        CategoryCubit similarProduct=BlocProvider.of<CategoryCubit>(context);
                        return ConditionalBuilder(
                          condition:state is! GetItemsForSubCategoryLoading &&similarProduct.itemsSubCategoryList.isNotEmpty,
                          builder: (context){
                            return  ProductCard(
                              isFavoriteMap:similarProduct.itemsForSubCategoryFavorite,
                              product:similarProduct.itemsSubCategoryList ,
                    
                              categoryName: 'similar_products'.tr(),
                            );
                          },
                          fallback:  (context){
                            return Skeletonizer(
                              enabled: true,
                              child: ProductCard(
                                isFavoriteMap:similarProduct.itemsForSubCategoryFavorite,
                                product:similarProduct.itemsSubCategoryList ,
                    
                                categoryName: 'similar_products'.tr(),
                              ),
                            );
                          },
                    
                        );
                      },
                    
                    ),
                  ),
                ),


                60.verticalSpace,
                //
                // 10.verticalSpace,
                // Padding(
                //   padding: const EdgeInsetsDirectional.only(
                //     start: 16,
                //
                //   ),
                //   child: ProductCard(
                //     imagePath: AppAssets.appleTest2Icon,
                //
                //     productName: 'product'.tr(),
                //     price: '3.000',
                //     categoryName: 'recently_ordered_products'.tr(),
                //   ),
                // ),
              ],
            ),
          ),

          SizedBox( width: MediaQuery.sizeOf(context).width*.7,child: Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: DefaultButton(

    hasIcon: true,
              icon: SvgPicture.asset(AppAssets.cartAddIcon),
              text: 'add_to_cart'.tr(),function: (){


              BlocProvider.of<AddOrderCubit>(context).addItem(productId: productId);

            },backgroundColor: AppColors.mainAppColor,),
          ))
        ],
      ),
    );
  }
}
