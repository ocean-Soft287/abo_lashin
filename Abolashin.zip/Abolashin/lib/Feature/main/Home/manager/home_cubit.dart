import 'dart:convert';


import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constans/constants.dart';
import '../../../../core/network/remote/dioHelper.dart';
import '../../../../core/network/remote/encrupt.dart';

import '../../../../core/network/remote/end_point.dart';
import '../../Add Order/manager/add_order_cubit.dart';
import '../../cart/screen/cart_screen.dart';
import '../../category/screen/category_screen.dart';
import '../../menu/screen/menu_screen.dart';
import '../model/banar_model.dart';
import '../../category/model/main_category_model.dart';
import '../model/offer_model.dart';
import '../model/product_model.dart';
import '../model/subCategory_model.dart';
import '../widget/home_screen_Wi.dart';
import 'home_state.dart';


class HomeCubit extends Cubit<HomeState> {
  HomeCubit() :super(InitializeHome());

  int currentIndex=0;
  changeSelectIndexBottom({required int index})
  {
    currentIndex=index;
    emit(ChangeIndexBottom());

  }

  List<Widget>screen=[
    HomeScreenWi(),CategoryScreen(),CartScreen(), MenuScreen(),


  ];




  List<BannerModel> bannerImageList=[];
  void getBannerImage() {
    emit(GetBannerImageLoading());
    DioHelper.getData(url: '/api/Baner1').then((value) {
      print(value.data);
      print('الداتا بعد فك التشفير');
      final decryptedText = decrypt(value.data, privateKey, publicKey);
      print(decryptedText);

      List<dynamic> jsonList = jsonDecode(decryptedText);
      bannerImageList = jsonList.map((json) => BannerModel.fromJson(json)).toList();

      emit(GetBannerImageSuccess());
    }).catchError((error) {
      print(
          'Error In Function Get Banner Image This Error ${error.toString()}');
      emit(GetBannerImageError());
    });
  }


  Map<int, bool> itemsBestSellerFavorite = {};
  List<ProductModel> bestSellerList=[];
  void getBestSellers() {
    emit(GetBestSellerLoading());
    DioHelper.getData(url: '/api/Product/GetProductsWithBestSeller?pageNumber=1&pageSize=100&CustomerID=$CustomerID').then((value) {
      print(value.data);
      if (value.statusCode == 200) {

        final decryptedText = decrypt(value.data, privateKey, publicKey);
        print(decryptedText);


        List<dynamic> jsonList = jsonDecode(decryptedText);


        bestSellerList = jsonList.map((json) => ProductModel.fromJson(json)).toList();

        for (var element in  bestSellerList) {
          itemsBestSellerFavorite.addAll({
            element.productId:element.isFavorite,
          });
        }
        emit(GetBestSellerSuccess());
      } else {
        print('Failed with status code: ${value.statusCode}');
        emit(GetBestSellerError());
      }


    }).catchError((error) {
      print(
          'Error In Function get Get Best Seller This Error ${error.toString()}');
      emit(GetBestSellerError());
    });
  }


  Map<int, bool> itemsNewProductFavorite = {};
  List<ProductModel> newProductList=[];
  void getNewProduct() {
    emit(GetNewProductLoading());
    DioHelper.getData(url: '/api/Product/GetNewProducts?pageNumber=1&pageSize=100&CustomerID=$CustomerID').then((value) {
      print(value.data);
      if (value.statusCode == 200) {

        final decryptedText = decrypt(value.data, privateKey, publicKey);
        print(decryptedText);


        List<dynamic> jsonList = jsonDecode(decryptedText);


        newProductList = jsonList.map((json) => ProductModel.fromJson(json)).toList();


        for (var element in  newProductList) {
          itemsNewProductFavorite.addAll({
            element.productId:element.isFavorite,
          });
        }

        emit(GetNewProductSuccess());
      } else {
        print('Failed with status code: ${value.statusCode}');
        emit(GetNewProductError());
      }


    }).catchError((error) {
      print(
          'Error In Function get Get New Product This Error ${error.toString()}');
      emit(GetNewProductError());
    });
  }




  Map<String, Map<String, dynamic>> itemSalah = {};
  void addItem({
    required int productId,
    required int quantity,
    required bool isVisibility,
    required context
  }) {

    if (itemSalah.containsKey(productId.toString())) {
      itemSalah[productId.toString()]?["isVisibility"] = isVisibility;
    } else {

      itemSalah[productId.toString()] = {
        "productId": productId,
        "quantity": quantity,
        "isVisibility": isVisibility,
      };
    }
    BlocProvider.of<AddOrderCubit>(context).addItem(productId: productId,context: context);
    emit(HomeUpdatedState(itemSalah));
  }

  void updateQuantity({required String productId, required int newQuantity,required context}) {
    if (itemSalah.containsKey(productId)) {
      itemSalah[productId]?["quantity"] = newQuantity;
      BlocProvider.of<AddOrderCubit>(context).addItem(productId: productId,context: context);
      emit(HomeUpdatedState(itemSalah));
    }


  }
  void updateQuantityQu({required String productId, required int newQuantity,required context}) {
    if (itemSalah.containsKey(productId)) {
      itemSalah[productId]?["quantity"] = newQuantity;
      BlocProvider.of<AddOrderCubit>(context).decreaseItem(productId: productId);
      emit(HomeUpdatedState(itemSalah));
    }


  }
  void showQuantity({required String productId}) {
    itemSalah[productId]?["isVisibility"] = true;
    emit(HomeUpdatedState(itemSalah)); // استخدم الحالة المحدثة
  }


  void hideQuantity({required String productId}) {
    itemSalah[productId]?["isVisibility"] = false;
    emit(HomeUpdatedState(itemSalah));
  }



  Map<int, bool> itemsOfferFavorite = {};
  List<OfferModel>offerList=[];
  void getOfferProduct() {
    emit(GetOfferProductLoading());
    DioHelper.getData(url: Endpoints.offerOne).then((value) {
      print(value.data);
      if (value.statusCode == 200) {

        final decryptedText = decrypt(value.data, privateKey, publicKey);
        print(decryptedText);


        List<dynamic> jsonList = jsonDecode(decryptedText);


        offerList = jsonList.map((json) => OfferModel.fromJson(json)).toList();


        for (var offer in offerList) {
          for (var item in offer.offerItems) {
            itemsOfferFavorite.addAll({
              item.productId: item.isFavorite,
            });
          }
        }


        emit(GetOfferProductSuccess());
      } else {
        print('Failed with status code: ${value.statusCode}');
        emit(GetOfferProductError());
      }


    }).catchError((error) {
      print(
          'Error In Function get Get Offer Product This Error ${error.toString()}');
      emit(GetOfferProductError());
    });
  }

  Map<int, bool> itemsOfferTwoFavorite = {};
  List<OfferModel>offerTwoList=[];
  void getOfferTwoProduct() {
    emit(GetOfferTwoProductLoading());
    DioHelper.getData(url: Endpoints.offerTwo).then((value) {
      print(value.data);
      if (value.statusCode == 200) {

        final decryptedText = decrypt(value.data, privateKey, publicKey);
        print(decryptedText);


        List<dynamic> jsonList = jsonDecode(decryptedText);


        offerTwoList = jsonList.map((json) => OfferModel.fromJson(json)).toList();


        for (var offerTwo in offerTwoList) {
          for (var item in offerTwo.offerItems) {
            itemsOfferTwoFavorite.addAll({
              item.productId: item.isFavorite,
            });
          }
        }


        emit(GetOfferTwoProductSuccess());
      } else {
        print('Failed with status code: ${value.statusCode}');
        emit(GetOfferTwoProductError());
      }


    }).catchError((error) {
      print(
          'Error In Function get Get Offer Two Product This Error ${error.toString()}');
      emit(GetOfferTwoProductError());
    });
  }



}