abstract class HomeState{}
class InitializeHome extends HomeState{}
class ChangeIndexBottom extends HomeState{}






class GetBannerImageLoading extends HomeState{}
class GetBannerImageSuccess extends HomeState{}
class GetBannerImageError extends HomeState{}



class GetBestSellerLoading extends HomeState {}
class GetBestSellerSuccess extends HomeState {}
class GetBestSellerError extends HomeState {}


class GetNewProductLoading extends HomeState {}
class GetNewProductSuccess extends HomeState {}
class GetNewProductError extends HomeState {}

class HomeUpdatedState extends HomeState {
  final Map<String, dynamic> itemSalah;

  HomeUpdatedState(this.itemSalah);
}



class GetOfferProductLoading extends HomeState {}
class GetOfferProductSuccess extends HomeState {}
class GetOfferProductError extends HomeState {}

class GetOfferTwoProductLoading extends HomeState {}
class GetOfferTwoProductSuccess extends HomeState {}
class GetOfferTwoProductError extends HomeState {}




