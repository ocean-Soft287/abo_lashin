import 'package:abolashin/Feature/main/Home/manager/home_cubit.dart';
import 'package:abolashin/Feature/main/category/model/product_model.dart';
import 'package:abolashin/Feature/main/product_details/screen/product_details_screen.dart';
import 'package:abolashin/core/sharde/widget/navigation.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constans/app_assets.dart';
import '../../../../core/constans/app_colors.dart';
import '../../../../core/constans/constants.dart';
import '../../../../core/network/local/chacheHelper.dart';
import '../../Add Order/manager/add_order_cubit.dart';
import '../../menu/Favorites/cubit/favorite_cubit.dart';
import '../../menu/Favorites/cubit/favorite_state.dart';
import 'item_category_offer.dart';

class ProductCard extends StatelessWidget {
  List product;
  final String categoryName;

  final dynamic isFavoriteMap;


  ProductCard({
    super.key,
    required this.product,
    required this.categoryName
    ,
   required this.isFavoriteMap


  });

  @override
  Widget build(BuildContext context) {
    currentLang = CacheHelper.getData(key: 'changeLang')??'ar';
    final currentLocale = context.locale;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(categoryName, style: GoogleFonts.alexandria(
              textStyle: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
                color:Colors.black,
              ),
            ),

            ),
            GestureDetector(
              onTap: () {
             navigato(context, ItemsCategoryOffer(

               isFavoriteMap: isFavoriteMap,

               categoryName:categoryName ,
               product: product,
             ));
              },
              child: Text(
                'see_more'.tr(),
                style: GoogleFonts.alexandria(
                  decoration: TextDecoration.underline,
                  decorationColor: AppColors.mainAppColor,
                  decorationThickness:2 ,

                  textStyle: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w400,
                    color:AppColors.mainAppColor,
                  ),
                ),
              ),
            )
          ],
        ),
        5.verticalSpace,

        SizedBox(
          height:236.h,

          child:

         ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: product.length,
              itemBuilder: (context, index) {

                return   Stack(
                  children: [
                    InkWell(
                      onTap: () {
                      // navigato(context, ProductDetailsScreen(productId:product[index].productId ,categoryId: product[index].categoryId,));
                      //
                      //
                     print(product[index].productImage);

                      },
                      child: Stack(
                        alignment: Alignment.centerLeft,
                        children: [
                          Container(
                          width: MediaQuery.sizeOf(context).width / 2,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                            ),
                            padding: const EdgeInsets.all(5),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CachedNetworkImage(
                                  imageUrl: product[index].productImage.toString()??'',
                                  placeholder: (context, url) => Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Center(
                                      child: CircularProgressIndicator(
                                        value: 1.0,
                                        color: AppColors.mainAppColor,
                                      ),
                                    ),
                                  ),
                                  errorWidget: (context, url, error) => const Icon(Icons.error),
                                  width: MediaQuery.sizeOf(context).width,
                                  height: 150.h,
                                ),

                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        RichText(
                                          text: TextSpan(
                                            children: [
                                              TextSpan(
                                                text: (product[index].priceAfterDiscount ?? 0.0).toStringAsFixed(2),
                                                style: GoogleFonts.alexandria(
                                                  fontSize: 16.sp,
                                                  fontWeight: FontWeight.w400,
                                                  color: AppColors.mainAppColor,
                                                ),
                                              ),
                                              TextSpan(
                                                text: 'currency'.tr(),
                                                style: GoogleFonts.alexandria(
                                                  fontSize: 12.sp,
                                                  fontWeight: FontWeight.w300,
                                                  color: AppColors.mainAppColor,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        if(product[index].price!=product[index].priceAfterDiscount)
                                          RichText(
                                            text: TextSpan(
                                              children: [
                                                TextSpan(
                                                  text: (product[index].price ?? 0.0).toStringAsFixed(2),
                                                  style: GoogleFonts.alexandria(
                                                    fontSize: 12.sp,
                                                    fontWeight: FontWeight.w400,
                                                    color: Colors.red,
                                                    decoration: TextDecoration.lineThrough,
                                                    decorationStyle: TextDecorationStyle.dashed,
                                                    decorationColor: Colors.red,
                                                    decorationThickness: 2.0, // زيادة سمك الخط المائل
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'currency'.tr(),
                                                  style: GoogleFonts.alexandria(
                                                    fontSize: 12.sp,
                                                    fontWeight: FontWeight.w300,
                                                    color: Colors.red,
                                                    decoration: TextDecoration.lineThrough, // خط مائل
                                                    decorationStyle: TextDecorationStyle.dashed, // تغيير النمط إلى خط متقطع
                                                    decorationColor: Colors.red, // تغيير لون الخط المائل
                                                    decorationThickness: 2.0, // زيادة سمك الخط المائل
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                      ],
                                    ),

                                  ],
                                ),
                                const SizedBox(height: 10),
                                AutoSizeText(
                                  (currentLocale.languageCode == 'ar')?
                                  product[index].productArName
                                  :
                                  product[index].productEnName
                                  ,
                                  maxLines: 2,
                                  maxFontSize: 12.sp,
                                  style: GoogleFonts.alexandria(
                                    textStyle: TextStyle(
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.w300,
                                      color: const Color(0xff5C5C5C),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          InkWell(
                            onTap: (){
                              BlocProvider.of<AddOrderCubit>(context).addItem(productId: product[index].productId);
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(0xffF7B700),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              width: 30,
                              height: 30,
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                                size: 25,
                              ),
                            ),
                          ),

                          // BlocBuilder(
                          //   builder: (context,state)
                          //   {
                          //     return
                          //   },
                          //   child:
                          // ),
//                           InkWell(
//                             onTap: () {
//                               // إظهار شريط الكمية
//                               BlocProvider.of<HomeCubit>(context).showQuantity(productId: product[index].productId.toString());
//
//                               // إخفاء شريط الكمية بعد 2 ثانية
//                               Future.delayed(Duration(seconds: 2), () {
//                                 BlocProvider.of<HomeCubit>(context).hideQuantity(productId: product[index].productId.toString());
//                               });
//                             },
//                             child: Container(
//                               decoration: BoxDecoration(
//                                 color: const Color(0xffF7B700),
//                                 borderRadius: BorderRadius.circular(17.r),
//                               ),
//                               width: 30.w,
//                               height: 30.h,
//                               child: const Icon(
//                                 Icons.add,
//                                 color: Colors.white,
//                                 size: 25,
//                               ),
//                             ),
//                           ),
//
// // هذا هو الجزء الذي يظهر شريط الكمية فقط إذا كانت isVisibility = true
//                           BlocProvider.of<HomeCubit>(context).itemSalah[product[index].productId.toString()]?["isVisibility"] ?? false
//                               ? Padding(
//                             padding: const EdgeInsets.all(4.0),
//                             child: Container(
//                               decoration: BoxDecoration(
//                                 color: const Color(0xffF7B700),
//                                 borderRadius: BorderRadius.circular(15),
//                               ),
//                               child: Row(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   IconButton(
//                                     icon: Icon(Icons.remove, color: Colors.white),
//                                     onPressed: () {
//                                       // تقليل الكمية إذا كانت أكبر من 1
//                                     //  BlocProvider.of<HomeCubit>(context).decreaseQuantity(productId: product[index].productId.toString());
//                                     },
//                                   ),
//                                   Text(
//                                     '${BlocProvider.of<HomeCubit>(context).itemSalah[product[index].productId.toString()]?["quantity"] ?? 0}',
//                                     style: TextStyle(color: Colors.white, fontSize: 20),
//                                   ),
//                                   IconButton(
//                                     icon: Icon(Icons.add, color: Colors.white),
//                                     onPressed: () {
//                                     //  BlocProvider.of<HomeCubit>(context).increaseQuantity(productId: product[index].productId.toString());
//                                     },
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           )
//                               : SizedBox(),  // إذا كانت isVisibility = false، لا يتم عرض شريط الكمية
//


                        ],
                      ),
                    ),
                    if(product[index].price!=product[index].priceAfterDiscount)
                      Positioned(
                        top:5,
                        right: 5,


                        child: Container(
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadiusDirectional.horizontal(
                                start:Radius.circular(20),
                                end: Radius.circular(20)
                            ),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          child: Text(
                            'special_offer'.tr(),
                            style: GoogleFonts.alexandria(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    BlocBuilder<FavoriteCubit,FavoriteState>(
                      builder: (context,state)
                      {
                        return Positioned(
                          top:5,
                          left: 5,
                          child: IconButton(
                            icon: Icon(
                              isFavoriteMap[product[index].productId] ?? false
                                  ? Icons.favorite
                                  : Icons.favorite_border,
                              color: isFavoriteMap[product[index].productId] ?? false
                                  ? Colors.red
                                  : Colors.grey,
                            ),

                            onPressed: (){
                              BlocProvider.of<FavoriteCubit>(
                                  context)
                                  .addFavorite(
                                favorite: isFavoriteMap
                                ,
                                productId: product[index].productId,
                              );

                            },  ),
                        );
                      },

                    ),
                  ],
                );
              },
              separatorBuilder: (context, index) {
                return const SizedBox(width: 5,);
              },
            ),
          ),

      ],
    );
  }
}
