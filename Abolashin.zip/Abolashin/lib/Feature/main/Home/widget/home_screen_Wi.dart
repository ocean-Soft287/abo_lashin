import 'package:abolashin/Feature/main/Home/widget/porduct_card.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:conditional_builder_null_safety/conditional_builder_null_safety.dart';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:skeletonizer/skeletonizer.dart';

import '../../../../core/constans/app_assets.dart';
import '../../../../core/constans/app_colors.dart';
import '../../../../core/constans/constants.dart';
import '../../../../core/network/local/chacheHelper.dart';
import '../../../../core/sharde/widget/navigation.dart';

import '../../Search/screen/search_screen.dart';
import '../../category/manager/category_cubit.dart';
import '../../category/manager/category_state.dart';
import '../../category/screen/category_screen.dart';
import '../../category/screen/product_categories_page.dart';
import '../manager/home_cubit.dart';
import '../manager/home_state.dart';

class HomeScreenWi extends StatelessWidget {
  const HomeScreenWi({super.key});

  @override
  Widget build(BuildContext context) {
    currentLang = CacheHelper.getData(key: 'changeLang')??'ar';
    final currentLocale = context.locale;
    return   Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 4),
      child: SingleChildScrollView(
        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
                   // Container(
                   //   margin: const EdgeInsets.symmetric(vertical: 5,),
                   //
                   //   decoration: BoxDecoration(
                   //     color: Colors.white,
                   //     borderRadius: BorderRadius.circular(30),
                   //
                   //   ),
                   //   child: Row(
                   //     children: [
                   //        Expanded(flex: 2,child: Padding(
                   //         padding: const EdgeInsets.symmetric(vertical: 0),
                   //         child: Column(
                   //
                   //           children: [
                   //
                   //           Text(
                   //             'الكويت - حولي - تونس',
                   //             style: GoogleFonts.alexandria(
                   //               textStyle: TextStyle(
                   //                 fontSize: 12.sp,
                   //                 fontWeight: FontWeight.w400,
                   //                 color: AppColors.mainAppColor,
                   //               ),
                   //             ),
                   //           ),
                   //           Text(
                   //             'your_address'.tr(),
                   //             style: GoogleFonts.alexandria(
                   //               textStyle: TextStyle(
                   //                 fontSize: 13.sp,
                   //                 fontWeight: FontWeight.w300,
                   //                 color: const Color(0xff5C5C5C),
                   //               ),
                   //             ),
                   //           ),
                   //
                   //         ],),
                   //       )),
                   //
                   //       Expanded(flex: 1,
                   //           child: Container(
                   //             padding: const EdgeInsets.symmetric(vertical: 5),
                   //             decoration: BoxDecoration(
                   //               color: const Color(0xffF1F1F1),
                   //               borderRadius: BorderRadius.circular(30),
                   //
                   //             ),
                   //             child: Row(
                   //               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                   //                                      children: [
                   //             InkWell(onTap: (){
                   //               BlocProvider.of<HomeCubit>(context).changeSelectIndexBottom(index: 2);
                   //
                   //             },child: SvgPicture.asset(AppAssets.cartNoEmptyIcon)),
                   //             // Text(
                   //             //   '0',
                   //             //   style: GoogleFonts.alexandria(
                   //             //     textStyle: TextStyle(
                   //             //       fontSize: 22.sp,
                   //             //       fontWeight: FontWeight.w400,
                   //             //       color: AppColors.mainAppColor,
                   //             //     ),
                   //             //   ),
                   //             // ),
                   //                                      ],
                   //                                    ),
                   //           ))
                   //     ],
                   //   ),
                   // ),
                   4.verticalSpace,
            InkWell(
              onTap: (){
               navigato(context, const SearchScreen());
              },
              child: Container(

                padding: const EdgeInsets.symmetric(vertical: 14,horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(50),

                ),
                child: Row(
                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'search'.tr(),
                      style: GoogleFonts.alexandria(
                        textStyle: TextStyle(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w400,
                          color:const Color(0xff6A6A6A),
                        ),
                      ),
                    ),
                    SvgPicture.asset(AppAssets.searchIcon)
                  ],
                ),
              ),
            ),
            10.verticalSpace,
            Padding(

              padding: const EdgeInsets.symmetric(horizontal: 10)
              ,
              child:  BlocBuilder<HomeCubit, HomeState>(


                builder: (context, state) {

                  if (BlocProvider.of<HomeCubit>(context).bannerImageList.isEmpty) {
                    return Skeletonizer(
                      enabled: true,
                      child: Image.asset(
                        AppAssets.searchIcon,
                        height: 100.h,
                        fit: BoxFit.fill,
                      ),
                    );
                  }

                  return CarouselSlider.builder(
                    itemCount:BlocProvider.of<HomeCubit>(context).bannerImageList.length,
                    itemBuilder: (context, index, realIndex) {
                      return ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: CachedNetworkImage(

                          width: MediaQuery.sizeOf(context).width,
                          imageUrl:
                          BlocProvider.of<HomeCubit>(context).bannerImageList[index].imagePath,
                          placeholder: (context, url) => Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Center(
                              child: CircularProgressIndicator(
                                value: 1.0,
                                color: AppColors.mainAppColor,
                              ),
                            ),
                          ),
                          errorWidget: (context, url, error) => const Icon(Icons.error),
                          fadeInDuration: const Duration(seconds: 1),
                          height: 100.h,
                          fit: BoxFit.fill,
                        ),
                      );
                    },
                    options: CarouselOptions(
                      autoPlay: true,
                      enlargeCenterPage: false,
                      aspectRatio: 20 / 9,
                      viewportFraction: 1.0,

                    ),
                  );
                },
              )
              ,


            ),
             15.verticalSpace,


            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'shop_by_categories'.tr(),
                  style: GoogleFonts.alexandria(
                    textStyle: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                      color:Colors.black,
                    ),)
                ),
                GestureDetector(
                  onTap: () {
                    BlocProvider.of<HomeCubit>(context).changeSelectIndexBottom(index: 1);
                  },
                  child: Text(
                    'see_more'.tr(),
                    style: GoogleFonts.alexandria(
                      decoration: TextDecoration.underline,
                      decorationColor: AppColors.mainAppColor,
                      decorationThickness:2 ,

                      textStyle: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w400,
                        color:AppColors.mainAppColor,
                      ),
                  ),
                ),
                )
              ],
            ),
            10.verticalSpace,


            SizedBox(
              height: 120.h,
              child: BlocBuilder<CategoryCubit, CategoryState>(
                builder: (context, state) {
                  CategoryCubit mainCategoryCubit = BlocProvider.of<CategoryCubit>(context);
                  return ConditionalBuilder(
                    condition: state is GetMainCategorySuccess,
                    builder: (context) {
                      return ListView.builder(

                        scrollDirection: Axis.horizontal,
                        physics: const AlwaysScrollableScrollPhysics(),
                        itemCount: mainCategoryCubit.mainCategoryList.isNotEmpty ? mainCategoryCubit.mainCategoryList.length : 0,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: InkWell(
                              onTap: () {
                                navigato(
                                  context,
                                  ProductCategoriesPage(
                                    categoryId: mainCategoryCubit.mainCategoryList[index].categoryId,
                                    categoryName: (currentLocale.languageCode == 'ar')
                                        ? mainCategoryCubit.mainCategoryList[index].categoryArName.toString()
                                        : mainCategoryCubit.mainCategoryList[index].categoryEnName.toString(),
                                  ),
                                );
                              },
                              child: MainCategoryCard(
                                categoryName: (currentLocale.languageCode == 'ar')
                                    ? mainCategoryCubit.mainCategoryList[index].categoryArName.toString()
                                    : mainCategoryCubit.mainCategoryList[index].categoryEnName.toString(),
                                imagePath: mainCategoryCubit.mainCategoryList[index].categoryImage.toString(),
                              ),
                            ),
                          );
                        },
                      );
                    },
                    fallback: (context) {
                      return Skeletonizer(
                        enabled: true,
                        child: ListView.builder(
                          // تمكين التمرير الأفقي هنا أيضاً
                          scrollDirection: Axis.horizontal,
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: 10,
                          itemBuilder: (context, index) {
                            return const Padding(
                              padding: EdgeInsets.only(right: 10.0),  // تحديد المسافة هنا أيضًا
                              child: MainCategoryCard(
                                categoryName: '         ',
                                imagePath: '            ',
                              ),
                            );
                          },
                        ),
                      );
                    },
                  );
                },
              ),
            ),







            20.verticalSpace,


            BlocBuilder<HomeCubit,HomeState>(
              builder: (context,state){
                HomeCubit bestSellerProduct=BlocProvider.of<HomeCubit>(context);
                return ConditionalBuilder(
                  condition:state is! GetBestSellerLoading &&bestSellerProduct.bestSellerList.isNotEmpty,
                  builder: (context){
                  return  ProductCard(
                    isFavoriteMap:bestSellerProduct.itemsBestSellerFavorite ,
                      product:bestSellerProduct.bestSellerList ,

                      categoryName: 'bestsellers'.tr(),
                    );
                  },
                  fallback:  (context){
                   return Skeletonizer(
                     enabled: true,
                     child: ProductCard(
                        product:bestSellerProduct.bestSellerList ,
                       isFavoriteMap:bestSellerProduct.itemsBestSellerFavorite ,
                        categoryName: 'bestsellers'.tr(),
                      ),
                   );
                  },

                );
              },

            ),
            10.verticalSpace,

            BlocBuilder<HomeCubit,HomeState>(
              builder: (context,state){
                HomeCubit newProduct=BlocProvider.of<HomeCubit>(context);
                return ConditionalBuilder(
                  condition:state is! GetNewProductLoading &&newProduct.newProductList.isNotEmpty,
                  builder: (context){
                    return  ProductCard(
                      isFavoriteMap:newProduct.itemsNewProductFavorite ,
                      product:newProduct.newProductList ,

                      categoryName: 'new_arrival'.tr(),
                    );


                  },
                  fallback:  (context){
                    return Skeletonizer(
                      enabled: true,
                      child: ProductCard(
                        product:newProduct.newProductList ,
                          isFavoriteMap:newProduct.itemsNewProductFavorite,
                          categoryName: 'new_arrival'.tr(),
                      ),
                    );
                  },

                );
              },

            ),

            10.verticalSpace,

            BlocBuilder<HomeCubit,HomeState>(
              builder: (context,state){
                HomeCubit offerProduct=BlocProvider.of<HomeCubit>(context);
                return ConditionalBuilder(
                  condition:state is! GetOfferProductLoading ,
                  builder: (context){
                    return

                      ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: offerProduct.offerTwoList.length,
                        itemBuilder: (context,index)
                        {
                          return
                            ( offerProduct.offerTwoList[index].showOffer==1)?
                            const SizedBox():
                            ProductCard(
                                isFavoriteMap:offerProduct.itemsOfferTwoFavorite ,
                                product:offerProduct.offerTwoList[index].offerItems,

                                categoryName:
                                (currentLocale.languageCode=='ar')?
                                offerProduct.offerTwoList[index].offerName:
                                offerProduct.offerTwoList[index].offerName

                            );
                        },
                        separatorBuilder: (context,index)
                        {
                          return const SizedBox(height: 10,);
                        },


                      );




                  },
                  fallback:  (context){
                    return Skeletonizer(
                      enabled: true,
                      child: ProductCard(
                        product:offerProduct.newProductList,
                        isFavoriteMap:offerProduct.itemsOfferTwoFavorite,
                        categoryName: 'ff',
                      ),
                    );
                  },

                );
              },

            ),
            10.verticalSpace,

            BlocBuilder<HomeCubit,HomeState>(
              builder: (context,state){
                HomeCubit offerProduct=BlocProvider.of<HomeCubit>(context);
                return ConditionalBuilder(
                  condition:state is! GetOfferProductLoading ,
                  builder: (context){
                    return

                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                        itemCount: offerProduct.offerList.length,
                        itemBuilder: (context,index)
                        {
                          return
                            ( offerProduct.offerList[index].showOffer==1)?
                                const SizedBox():
                            ProductCard(
                            isFavoriteMap:offerProduct.itemsOfferFavorite ,
                            product:offerProduct.offerList[index].offerItems,

                            categoryName:
                            (currentLocale.languageCode=='ar')?
                            offerProduct.offerList[index].offerName:
                            offerProduct.offerList[index].offerName

                          );
                        },
                        separatorBuilder: (context,index)
                        {
                          return const SizedBox(height: 10,);
                        },


                    );




                  },
                  fallback:  (context){
                    return Skeletonizer(
                      enabled: true,
                      child: ProductCard(
                        product:offerProduct.newProductList,
                        isFavoriteMap:offerProduct.itemsNewProductFavorite,
                        categoryName: 'ff',
                      ),
                    );
                  },

                );
              },

            ),



          ],
        ),
      ),
    );
  }
}






